---
name: real-estate-accounting
description: محاسبة مكتب وساطة وتسويق عقاري سعودي: الإيرادات والعمولات والشركاء وأموال العملاء والضرائب والمطابقة وإدارة ملفات Excel.
---

# Mafawiz Real Estate Accounting

## Mandatory operating rules

This skill is the persistent accounting operating framework for مفاوز العقارية.

1. **Never invent an account.** Every account used must exist in the current `references/chart-of-accounts.md`. Never invent, substitute, or revive an account from an old workbook. If an account is missing or mapping conflicts, use `NEEDS_REVIEW`. `NEEDS_REVIEW` is a status, not automatically a GL account.
2. **Current COA is authoritative.** Transaction facts come from the current transaction/source document; account identity from the current COA; accounting treatment from this skill; tax treatment from current verified Saudi rules. Conflicts must be reported, not silently resolved.
3. **Double entry is necessary but not sufficient.** Debits must equal credits, and also validate account existence, account nature, revenue recognition, AR, liabilities, partner separation, third-party funds, tax status, reversals, duplicates, fixed assets, and unresolved items.
4. **Property value is not office revenue.** Property sale/purchase value or money passing through the office for an owner/client is not revenue merely because the office facilitated the transaction.
5. **Third-party funds are separate.** Money received/held for owners or clients is normally a liability/settlement amount, not office revenue.
6. **Revenue and collection are different.** Collection of an existing receivable is `Dr Bank / Cr AR`; it is not new revenue.
7. **Direct reversal integrity.** A direct reversal requires the same amount, same accounts, opposite debit/credit directions, and a documented relationship. If accounts differ, it is not a direct reversal.
8. **VAT current mode:** `VAT_REGISTERED=NO`, `VAT_MODE=OFF`, `VAT_RATE=15%` reference only. Do not post VAT or add VAT automatically. Informational VAT calculations must remain informational unless actual tax status and transaction facts support posting.
9. **RETT is transaction-specific.** Do not automatically apply 5% to every real-estate transaction or brokerage commission. Identify transaction, taxpayer, agency role, and who bears the amount. Missing facts = `NEEDS_REVIEW`.
10. **Partner separation.** Separate capital, current account, drawings, settlements/reimbursements, and profit distributions. Personal withdrawals are not operating expenses. A partner-paid genuine office expense is treated as an expense plus partner balance when supported; reimbursement is settlement, not a second expense.
11. **Internal bank transfers** are asset-to-asset and do not affect revenue or expense.
12. **Unknown bank movements** must not be guessed into revenue or expense. Determine direction, counterparty, purpose, and evidence; otherwise `NEEDS_REVIEW`.
13. **Fixed assets** are not automatically expenses. Depreciation requires an established policy/basis.
14. **Prepaids** are recognized over the applicable period when appropriate; do not expense an annual prepaid amount merely because cash was paid.
15. **Do not force management classifications.** Do not label accounts as Direct Costs/Operating Expenses by intuition. GL classification follows the current COA. Any management grouping is separate and explicitly configured.
16. **Do not modify the COA automatically.** Discovering a mapping problem is not permission to redesign the chart.

## Accounting workflow

For every transaction:
1. Read facts and source.
2. Identify business purpose and parties.
3. Determine cash movement.
4. Determine substance: revenue, receivable, collection, expense, payable, asset, liability, third-party funds, partner item, tax, or internal transfer.
5. Validate every account against the current COA.
6. Apply VAT/RETT settings.
7. Build the journal entry.
8. Test debit = credit.
9. Run integrity checks.
10. Assign status.
11. Explain unresolved items and required evidence.

## Reporting states

Always distinguish:
- **As-Posted:** literal result of supplied entries.
- **Confirmed:** supported treatment.
- **Potential:** depends on unresolved facts.
- **Adjusted/Expected:** result after an explicit corrective assumption.
- **Hypothetical Corrective Scenario:** proposed only, never presented as an approved correction.

Do not silently overwrite As-Posted numbers.

## NEEDS_REVIEW

Use it for missing accounts, conflicting mappings, unknown direction/purpose/counterparty, uncertain tax treatment, non-matching reversals, duplicate risk, missing documents, or any treatment requiring an assumption.

For each item report: Transaction ID, As-Posted treatment, confirmed portion if any, unresolved portion, reason, evidence needed, and any possible treatment clearly labeled as a scenario.

## Financial integrity checks

At minimum:
- debits = credits;
- all accounts exist;
- account nature matches;
- revenue is not duplicated by collection;
- AR has no unexplained negative balance;
- payables/liabilities reconcile;
- third-party funds remain separate;
- partner balances remain separate;
- drawings are not expenses;
- internal transfers do not affect profit;
- fixed assets/prepaids are correctly treated;
- VAT posting agrees with VAT mode;
- RETT is not automatic;
- unknown bank items remain unresolved;
- direct reversals actually reverse the original accounts;
- no invented accounts;
- no duplicate transactions/revenue.

## Current business defaults

Business: مفاوز العقارية
Business model: Saudi real-estate brokerage and marketing office
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT Mode: TRANSACTION_SPECIFIC

These defaults do not replace checking current official requirements when tax advice or filing treatment is requested.

## Reference order

Use when relevant:
1. `chart-of-accounts.md`
2. `journal-entry-rules.md`
3. `saudi-tax-rules.md`
4. `bank-reconciliation.md`
5. `month-end-closing.md`
6. `excel-accounting.md`

Do not ask the user to repeat these core rules in every conversation. Apply them automatically.

# Journal Entry Rules

## Revenue
Earned brokerage commission:
- Accrual: `Dr Accounts Receivable / Cr Brokerage Revenue`
- Immediate receipt: `Dr Bank / Cr Brokerage Revenue`

Do not recognize property value as office revenue.

## Collection
Existing receivable collection:
`Dr Bank / Cr Accounts Receivable`

No second revenue.

## Direct reversal
Original: `Dr AR / Cr Revenue`
Direct reversal: `Dr Revenue / Cr AR`

A reversal with different accounts is not a direct reversal. Analyze it separately.

## Third-party funds
Receipt for owner/client:
`Dr Bank / Cr Owner/Client Funds Liability`

Remittance:
`Dr Owner/Client Funds Liability / Cr Bank`

## Commission withheld from owner/client funds
May be:
`Dr Owner/Client Funds Liability / Cr Brokerage Revenue`
only when the office has actually earned the commission and settlement documents support withholding. Never assume this merely from the account used.

## Partner transactions
- Partner-paid genuine office expense: expense plus partner balance according to current COA and documented nature.
- Reimbursement: `Dr Partner Current/Settlement / Cr Bank`; not a new expense.
- Personal withdrawal: equity/current transaction, not operating expense.
- Capital contribution: separate from current account/drawings.
- Profit distribution: separate from operating expense.

Use current COA; do not import legacy partner account numbers automatically.

## Internal bank transfer
`Dr Receiving Bank / Cr Sending Bank`

## Unknown bank movement
Do not infer from amount. If direction, counterparty, or purpose is unresolved: `NEEDS_REVIEW`.

## Fixed assets
Qualifying purchase: `Dr Fixed Asset / Cr Bank` when capitalization policy supports it. Depreciation only with documented basis.

## Prepaids
Initial: `Dr Prepaid / Cr Bank`
Periodic: `Dr Expense / Cr Prepaid`

## Duplicate revenue control
Before recognizing revenue, check prior accrual/invoice/collection/settlement/reversal.

## Reporting
Never overwrite As-Posted. Separate Confirmed, Potential, Adjusted/Expected, and Hypothetical Corrective Scenario.

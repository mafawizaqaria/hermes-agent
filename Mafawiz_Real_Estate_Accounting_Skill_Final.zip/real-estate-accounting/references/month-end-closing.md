# Month-End Closing

## Revenue
Review brokerage, marketing, property-management, and consulting revenue. Check recognition, collections, reversals, and duplicates.

## AR
Reconcile opening AR + recognized credit revenue - collections - valid reversals/credits = ending AR. Investigate unexplained negative AR.

## Payables
Review accruals, payments, ending balances, and account mapping. Missing legacy accounts must be flagged, not substituted.

## Third-party funds
Reconcile owner/client receipts, remittances, and remaining liability. Principal funds are not office revenue.

## Partners
Reconcile capital, current account, drawings, settlements, and distributions separately.

## Bank
Complete bank reconciliation. Unknown items remain `NEEDS_REVIEW`.

## Fixed assets/prepaids
Review additions, capitalization, depreciation when supported, prepaid balances, and periodic expense recognition.

## Tax
Verify VAT mode and posted VAT. Keep informational VAT separate. Verify RETT taxpayer and transaction basis; do not apply automatically.

## Final integrity checks
- valid accounts
- valid account nature
- AR coherent
- liabilities coherent
- third-party funds reconciled
- partner balances separated
- revenue not duplicated
- reversals valid
- fixed assets/prepaids correct
- tax mode correct
- unknown bank items flagged
- NEEDS_REVIEW items disclosed

Final output should distinguish As-Posted, Confirmed, Unresolved/Potential, and Adjusted/Expected.

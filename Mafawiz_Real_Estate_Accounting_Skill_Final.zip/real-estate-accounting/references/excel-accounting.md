# Excel Accounting

## Source of truth
Transaction facts come from the transaction sheet. Account identity comes from the current COA. Accounting treatment comes from this skill. Tax treatment comes from current tax rules. Supporting documents resolve uncertain party/purpose information.

An old workbook is a training/test artifact unless explicitly declared current.

## Account mapping verification
For every debit/credit account:
1. account exists in current COA;
2. name matches;
3. category/nature matches;
4. debit/credit use is plausible.

Conflict = `NEEDS_REVIEW`.

Never create an account because an Excel row contains one.

## Common fields
Transaction ID, Date, Description, Transaction Type, Amount, Currency, Cash Movement, Debit Account, Credit Account, VAT Mode, RETT, Status, Notes.

Deal/property/owner/client/agent/partner/invoice/bank IDs are conditional and only required when relevant.

## Statuses
CONFIRMED
COMPLETED
ACCRUED
INFORMATIONAL
NEEDS_REVIEW
HYPOTHETICAL_CORRECTIVE_SCENARIO

## Reporting
Separate literal ledger calculations from adjustments, management reporting, and tax information.

Do not silently edit source rows to make results look correct.

## Training dataset
The Mafawiz controlled dataset is synthetic/controlled test material. It does not override the current COA. Legacy account mappings in test data must be flagged when absent from the current chart.

## Workbook integrity
Check debit=credit, valid account IDs, duplicate transaction IDs, duplicate revenue, collection vs revenue, reversal integrity, third-party funds, partner separation, VAT mode vs VAT posting, and unresolved bank movements.

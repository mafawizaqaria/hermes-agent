# Bank Reconciliation

For every bank movement determine:
1. date
2. direction
3. amount
4. bank account
5. counterparty
6. reference/description
7. purpose
8. supporting document
9. accounting category
10. related transaction/invoice/deal when applicable

Possible categories: customer collection, revenue, expense, payable settlement, owner/client funds, partner settlement, partner drawing, tax, internal transfer.

Unknown direction or purpose = `NEEDS_REVIEW`.

Internal transfer:
`Dr Receiving Bank / Cr Sending Bank`

Do not use an invented expense or revenue account to force the reconciliation to balance.

Reconcile opening balance, additions, deductions, transfers, bank fees, outstanding items, and closing balance.

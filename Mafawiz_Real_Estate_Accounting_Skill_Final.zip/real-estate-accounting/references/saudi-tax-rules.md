# Saudi Tax Handling

## Current operating configuration
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT: transaction-specific

When tax advice or filing treatment is requested, current official requirements must be checked rather than relying only on these configuration defaults.

## VAT
When VAT Mode is OFF:
- no output VAT posting;
- no input VAT posting;
- no automatic VAT addition;
- no VAT payable from ordinary current-mode transactions.

Informational VAT may be calculated if explicitly requested, but must be labeled informational and must not be posted automatically.

When VAT is activated, determine registration/status, taxable nature, tax point, consideration, tax-inclusive/exclusive basis, and correct accounts. Never infer VAT solely because a transaction is real estate.

## RETT
Do not automatically post 5% RETT. Determine transaction type, taxpayer, agency role, and who bears the amount. If unresolved: `NEEDS_REVIEW`.

Tax entries must have a valid transaction basis, account mapping, tax status, and documented reason.

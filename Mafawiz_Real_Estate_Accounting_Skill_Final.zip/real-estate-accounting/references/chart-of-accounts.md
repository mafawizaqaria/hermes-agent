# Chart of Accounts — Source of Truth

This file is authoritative for account identity and account nature.

## Mandatory controls
- Use only accounts present in the current COA.
- Never invent or substitute an account.
- Never create a suspense account merely to make a balance work.
- If an account is absent: `NEEDS_REVIEW`.
- Do not modify this file automatically during transaction analysis.

Historical workbooks/test datasets may contain legacy accounts such as `2130`, `2220`, or other mappings that are absent from the current chart. Historical mappings never override the current COA.

When a historical row references a missing account:
1. preserve the As-Posted fact;
2. do not invent a replacement;
3. flag the mapping as `NEEDS_REVIEW`;
4. request/identify the evidence needed for the correct current account.

Before posting, verify existence, name, category, and intended debit/credit behavior.

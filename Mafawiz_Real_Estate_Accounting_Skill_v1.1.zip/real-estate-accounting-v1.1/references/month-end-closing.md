# Month-End Closing — v1.1

## Revenue
Review brokerage, marketing, property-management, and consulting revenue.
Ensure collections are not counted as new revenue.

## AR
Reconcile opening AR + debit movements - credit movements = closing AR.
Negative AR must be reported As-Posted and investigated; never force it to zero.

## Third-party funds
For each receipt:
- Bank ↑
- Liability ↑

For each remittance:
- Bank ↓
- Liability ↓

Reconcile ending `2410`.

## Partners
Reconcile separately:
- 3100 contributions
- 3110 current account
- 3200 drawings
- 3210 settlements
- 3300 distributions

Partner-paid expense:
- expense remains recognized;
- credit to 3110 represents amount owed to partner.

Reimbursement:
- debit 3110;
- credit bank;
- does not reverse the expense.

## Bank
Preserve known movement direction.
Unknown purpose/counterparty remains `NEEDS_REVIEW`.

## Final integrity checks
- current COA actually loaded;
- no contradiction between response and current COA;
- correct asset/liability direction;
- partner drawings not confused with partner current;
- reimbursements not described as expense reversals;
- third-party funds not described as asset-to-asset transfers;
- no duplicate revenue;
- VAT/RETT rules respected;
- direct reversals use the same accounts in opposite directions.

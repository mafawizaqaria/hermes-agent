# Journal Entry Rules — v1.1

## 1. Brokerage revenue accrual
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

## 2. Collection
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Collection is not new revenue.

## 3. Third-party funds

### Receipt for owner/client
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

Effect:
- Bank asset increases.
- Third-party liability increases.
- Revenue is unaffected.
- Expense is unaffected.

### Remittance to owner/client
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

Effect:
- Bank asset decreases.
- Third-party liability decreases.
- Revenue is unaffected.
- Expense is unaffected.

Never describe receipt of third-party funds as decreasing the liability.

## 4. Commission withheld from third-party funds
When documents establish that Mafawiz has earned a commission and it is withheld from owner/client funds:
`Dr 2410 Owner / Client Funds Payable`
`Cr 4100 Brokerage Revenue`

Do not assume this treatment without evidence.

## 5. Direct reversal integrity
Original:
`Dr A / Cr B`

Direct reversal:
`Dr B / Cr A`

Direct reversal requires:
- same amount;
- same two accounts;
- opposite sides;
- documented relationship.

If accounts differ, analyze as correction/reclassification/settlement and use `NEEDS_REVIEW` if the relationship is not established.

## 6. Partner drawings
Personal withdrawal:
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

Effect:
- Bank decreases.
- Contra-equity/drawings increases.
- No operating expense.
- Do not say that `3110 Partner Current Account` decreased unless a separate documented current-account entry exists.

## 7. Partner-paid office expense
Example: partner personally pays general office advertising:
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

Effect:
- Expense increases.
- Office obligation/current balance owed to partner increases (credit to 3110).
- Bank is unaffected at this stage.

## 8. Partner reimbursement
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

Effect:
- Partner current balance owed by office decreases/settles.
- Bank decreases.
- The original expense remains recognized.
- No new expense.
- No expense reversal.

## 9. Internal bank transfer
`Dr 1110 Additional Bank`
`Cr 1100 Main Bank`

No revenue or expense.

## 10. Unknown bank movement
Preserve known facts.

If source says “outgoing”, direction = OUTGOING is known.
If source says “incoming”, direction = INCOMING is known.

Only unresolved fields remain unknown, such as:
- counterparty;
- purpose;
- accounting nature;
- supporting document.

Do not classify an unknown-purpose outflow as expense automatically.

## 11. Fixed asset
Qualifying equipment purchase:
`Dr 1410 Computers & Office Equipment`
`Cr 1100 Main Bank`

Not operating expense at purchase.

## 12. Prepaid software
Initial:
`Dr 1310 Prepaid Software & Subscriptions`
`Cr 1100 Main Bank`

Periodic recognition:
`Dr 6500 Software & Subscriptions Expense`
`Cr 1310 Prepaid Software & Subscriptions`

## 13. Revenue integrity
Before changing revenue, identify the original transaction nature:
- revenue recognition;
- AR collection;
- liability settlement;
- third-party funds;
- refund/reversal.

Do not reduce revenue merely because a later entry contains a revenue account.

## 14. Current COA consistency
After loading the current COA:
- use its current account definitions;
- do not rely on stale conversation memory;
- do not say an account is missing if it is present in the current file.

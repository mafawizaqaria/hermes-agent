# Bank Reconciliation Rules — v1.1

## Preserve known facts
A bank movement has four different information dimensions:
1. Direction
2. Counterparty
3. Purpose
4. Accounting nature

These must not be collapsed into one “known/unknown” label.

If the source says the movement is outgoing:
- direction is known = OUTGOING;
- counterparty/purpose/nature may still be unknown.

If the source says incoming:
- direction is known = INCOMING.

Do not later describe a stated direction as unknown.

## Unknown movement
If counterparty, purpose, or nature cannot be established:
`Status = NEEDS_REVIEW`

Do not automatically classify as:
- expense;
- revenue;
- partner transaction;
- third-party funds.

## Internal transfer
`Dr Receiving Bank`
`Cr Sending Bank`

No P&L effect.

## Bank fees
When clearly identified:
`Dr 6810 Bank Fees`
`Cr 1100 Main Bank`

## Reconciliation integrity
Do not use `6900`, `9000`, `9100`, or `9200` merely to force a bank reconciliation to balance.

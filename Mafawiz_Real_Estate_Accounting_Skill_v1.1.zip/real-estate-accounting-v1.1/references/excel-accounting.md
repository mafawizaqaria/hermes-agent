# Excel Accounting Rules — v1.1

## Current-file precedence
When an Excel workbook or COA is reloaded, the current file contents override stale conversation memory.

Do not state that an account is absent if the current loaded COA shows it.

## Mapping
Validate every account against the current canonical COA.

If historical/test row uses a legacy code:
- preserve As-Posted;
- flag mapping if needed;
- do not silently remap.

## Known vs unknown fields
For bank rows, preserve each known field independently:
- Direction
- Counterparty
- Purpose
- Nature

A known OUTGOING direction must remain known even if purpose/counterparty are unknown.

## Partner rows
Do not collapse:
- drawings;
- current account;
- reimbursement;
- contribution;
- distribution.

## Reporting
Keep separate:
- As-Posted
- Confirmed
- Potential
- Adjusted/Expected
- Hypothetical Corrective Scenario

Do not silently edit source rows to make results look correct.

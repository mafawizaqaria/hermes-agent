# Install / Upgrade — v2.0.2

This release is designed for the current Mafawiz Hermes source install and Python 3.14 runtime.
It fixes the v2.0.1 dependency problem by keeping `openpyxl` out of Hermes' PM-managed environment.

## 1. Extract to staging

```bash
rm -rf /root/hermes-skill-v2.0.2
mkdir -p /root/hermes-skill-v2.0.2
unzip /root/hermes-agent-download/Mafawiz_Real_Estate_Accounting_Skill_v2.0.2.zip \
  -d /root/hermes-skill-v2.0.2
```

## 2. Verify the package

```bash
head -15 /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/SKILL.md
find /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2 \
  \( -type d -name '__pycache__' -o -type f -name '*.pyc' \)
```

Expected: `version: 2.0.2` and no compiled Python artifacts.

## 3. Activate current Hermes Python

```bash
cd /root/hermes-agent
source ./activate
command -v python
python --version
```

The current deployment should report Python 3.14.x.

## 4. Build the isolated skill runtime

Do not `pip install openpyxl` into Hermes itself. Run:

```bash
python /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/bootstrap_skill_runtime.py
```

This creates/repairs:

`/root/.hermes/skill-runtimes/real-estate-accounting`

and installs exact hash-checked dependencies there only.

## 5. Run compatibility preflight

```bash
python /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/hermes_compat_check.py \
  /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2
```

Do not install the skill unless it reports `"pass": true`.

## 6. Compile helper scripts with Hermes Python

```bash
rm -rf /tmp/mafwiz-pycache-v2.0.2
PYTHONPYCACHEPREFIX=/tmp/mafwiz-pycache-v2.0.2 python -m py_compile \
  /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/bootstrap_skill_runtime.py \
  /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/hermes_compat_check.py \
  /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/run_validator.py \
  /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2/scripts/validate_accounting_workbook.py
echo "PY_COMPILE_EXIT=$?"
rm -rf /tmp/mafwiz-pycache-v2.0.2
```

Expected: `PY_COMPILE_EXIT=0`.

## 7. Backup v1.6/current active skill

```bash
if [ -d /root/.hermes/skills/productivity/real-estate-accounting ]; then
  cp -a /root/.hermes/skills/productivity/real-estate-accounting \
    /root/.hermes/skills/productivity/real-estate-accounting-backup-pre-v2.0.2-$(date +%Y%m%d-%H%M%S)
fi
```

## 8. Stage and switch

```bash
rm -rf /root/.hermes/skills/productivity/real-estate-accounting-new
cp -a /root/hermes-skill-v2.0.2/real-estate-accounting-v2.0.2 \
  /root/.hermes/skills/productivity/real-estate-accounting-new
head -15 /root/.hermes/skills/productivity/real-estate-accounting-new/SKILL.md
```

If `version: 2.0.2` appears:

```bash
rm -rf /root/.hermes/skills/productivity/real-estate-accounting
mv /root/.hermes/skills/productivity/real-estate-accounting-new \
  /root/.hermes/skills/productivity/real-estate-accounting
```

## 9. Restart and verify

```bash
hermes skills list | grep -i real-estate-accounting
systemctl restart hermes-gateway
systemctl status hermes-gateway --no-pager
```

Then `/reset` in Telegram.

## 10. Validator usage after install

```bash
cd /root/.hermes/skills/productivity/real-estate-accounting
python scripts/run_validator.py /path/to/workbook.xlsx \
  --coa references/chart-of-accounts.md \
  --vat-mode OFF
```

The wrapper uses the isolated runtime; it does not depend on `openpyxl` being present in Hermes core Python.

# Excel Accounting Rules — v2.0

## Workbook as controlled interface

Excel is not the authority for account identity.
Current `chart-of-accounts.md` is authoritative.

## Mandatory xlsx practices

- Use the installed `xlsx` skill for creation/editing.
- Preserve formulas; never save a workbook loaded with `data_only=True`.
- Dates must be real Excel dates.
- Amounts must be numeric.
- Use Excel Tables / dynamic ranges for active data.
- All Arabic operational sheets RTL.
- Do not hide unresolved items by formatting.

## Status-driven reporting

Only `POSTED` affects active accounting reports.

Exclude:
- DRAFT
- NEEDS_REVIEW
- UNPOSTED
- VOIDED

REVERSED handling must follow active net-effect policy and linked reversal rows.

## Formula logic

Use normal balances:
- Asset = Debit - Credit
- Expense = Debit - Credit
- Liability = Credit - Debit
- Equity = Credit - Debit
- Revenue = Credit - Debit

Net Profit = Revenue - Expenses.

Do not derive accounting class from transaction description.

## Formula range

Avoid fixed row limits such as `$2:$1001` when the active table can grow.

Prefer structured table references.

## Journal table

Each POSTED record must be inside the active Journal table.

If a row exists below/outside the table, validator should flag it.

## Liabilities/assets

Schedules must include every active row.
Schedule totals should tie to related GL where applicable.

## Validation

Before "FINAL":
`python scripts/run_validator.py workbook.xlsx --coa references/chart-of-accounts.md`

Report validator output exactly.
Do not claim PASS if critical gates fail.


## Isolated Excel runtime

For this accounting skill, do not add `openpyxl` to Hermes core Python with raw pip.
Use `scripts/bootstrap_skill_runtime.py` once (and again after a Hermes Python patch change).
Then use `scripts/run_validator.py` for validation. The runtime lives outside the skill directory
so replacing/upgrading the skill does not silently alter Hermes dependencies.

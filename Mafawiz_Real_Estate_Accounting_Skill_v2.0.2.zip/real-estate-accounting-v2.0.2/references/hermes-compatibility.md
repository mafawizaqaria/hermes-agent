# Hermes Compatibility — Skill v2.0.2

## Baseline

- Hermes source install / current skill layout.
- Hermes PM-managed Python line: 3.14.x.
- Current Mafawiz deployment verified against Python 3.14.7 and PM pin `3.14.7+20260901`.
- Skill files remain under `~/.hermes/skills/...`; helper dependencies do **not** modify Hermes core.

## Dependency isolation

Hermes currently does not include `openpyxl` in the active PM Python used by Mafawiz.
The bundled `xlsx` skill documents `openpyxl` as a prerequisite, but Hermes' dependency
policy says its managed environment should not be mutated with raw `pip`/`uv`.

Therefore this skill uses a dedicated runtime:

`~/.hermes/skill-runtimes/real-estate-accounting`

Bootstrap it using the **current Hermes PM Python**:

```bash
cd /root/hermes-agent
source ./activate
python /path/to/skill/scripts/bootstrap_skill_runtime.py
```

The bootstrap installs exact, hash-checked wheels into the isolated runtime only:

- `openpyxl==3.1.5`
- `et_xmlfile==2.0.0`

It never installs those packages into the Hermes PM environment. If Hermes changes its
Python patch version, rerun the bootstrap; it rebuilds the skill runtime when the Python
patch does not match the active Hermes Python.

## Validator invocation

Preferred:

```bash
python scripts/run_validator.py workbook.xlsx --coa references/chart-of-accounts.md --vat-mode OFF
```

The wrapper dispatches to the isolated runtime. Do not call the validator with an arbitrary
system Python.

## Compatibility gate

After bootstrapping, run:

```bash
python scripts/hermes_compat_check.py /path/to/skill
```

`pass: true` requires:
- active host Python is 3.14.x;
- host patch version matches Hermes `pm/lock.json`;
- required skill files exist;
- no packaged `.pyc` / `__pycache__`;
- isolated runtime exists;
- its Python patch matches the active Hermes Python;
- `openpyxl` and `et_xmlfile` import successfully there.

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create/repair the isolated Python runtime for Mafawiz accounting skill v2.0.2.

This intentionally does NOT mutate Hermes' PM-managed dependency environment.
Run this script with the current Hermes PM Python after `source ./activate`.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import venv
from pathlib import Path

TARGET = (3, 14)
DEFAULT_RUNTIME = Path(os.environ.get(
    "MAFAWIZ_ACCOUNTING_RUNTIME",
    str(Path.home() / ".hermes" / "skill-runtimes" / "real-estate-accounting"),
)).expanduser()


def py_path(runtime: Path) -> Path:
    return runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run_capture(cmd: list[str]) -> tuple[int, str]:
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.returncode, p.stdout.strip()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runtime", type=Path, default=DEFAULT_RUNTIME)
    ap.add_argument("--rebuild", action="store_true")
    args = ap.parse_args()
    runtime = args.runtime.expanduser().resolve()
    req = Path(__file__).resolve().with_name("requirements.lock")

    result: dict[str, object] = {
        "skill": "real-estate-accounting",
        "skill_version": "2.0.2",
        "host_python": sys.version.split()[0],
        "host_executable": sys.executable,
        "runtime": str(runtime),
        "requirements": str(req),
        "rebuilt": False,
        "installed": False,
        "errors": [],
    }

    if sys.version_info[:2] != TARGET:
        result["errors"].append(
            f"host_python_mismatch: expected 3.14.x, got {sys.version.split()[0]}"
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 4
    if not req.is_file():
        result["errors"].append("requirements_lock_missing")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2

    runtime_python = py_path(runtime)
    rebuild = bool(args.rebuild)
    if runtime_python.is_file() and not rebuild:
        rc, out = run_capture([str(runtime_python), "-c", "import sys; print(sys.version.split()[0])"])
        if rc != 0 or out != sys.version.split()[0]:
            rebuild = True

    if rebuild and runtime.exists():
        shutil.rmtree(runtime)

    if not runtime_python.is_file():
        runtime.parent.mkdir(parents=True, exist_ok=True)
        venv.EnvBuilder(with_pip=True, clear=False, symlinks=True).create(runtime)
        result["rebuilt"] = True
        runtime_python = py_path(runtime)

    if not runtime_python.is_file():
        result["errors"].append("runtime_python_missing_after_create")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2

    install_cmd = [
        str(runtime_python), "-m", "pip", "install",
        "--disable-pip-version-check",
        "--require-hashes",
        "--only-binary=:all:",
        "-r", str(req),
    ]
    rc, out = run_capture(install_cmd)
    result["pip_output"] = out[-5000:]
    if rc != 0:
        result["errors"].append(f"dependency_install_failed: exit={rc}")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3

    rc, out = run_capture([
        str(runtime_python), "-c",
        "import sys, openpyxl, et_xmlfile; "
        "print(sys.version.split()[0]+'|'+openpyxl.__version__+'|'+getattr(et_xmlfile,'__version__','unknown'))",
    ])
    if rc != 0:
        result["errors"].append("runtime_import_check_failed")
        result["import_output"] = out
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3

    pyver, openpyxl_ver, et_ver = (out.split("|", 2) + ["", ""])[:3]
    result["runtime_python"] = str(runtime_python)
    result["runtime_python_version"] = pyver
    result["openpyxl"] = openpyxl_ver
    result["et_xmlfile"] = et_ver
    result["installed"] = True
    result["pass"] = not result["errors"]
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

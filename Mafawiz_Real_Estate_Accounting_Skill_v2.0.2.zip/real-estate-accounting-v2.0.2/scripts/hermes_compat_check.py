#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compatibility preflight for Mafawiz real-estate-accounting skill v2.0.2.

Read-only. Checks Hermes Python compatibility, PM pin, package hygiene, and the
skill's isolated runtime. It never installs packages or modifies Hermes.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

TARGET_PYTHON = (3, 14)
REQUIRED_FILES = (
    "SKILL.md",
    "references/chart-of-accounts.md",
    "references/accounting-engine.md",
    "references/journal-entry-rules.md",
    "references/workbook-schema.md",
    "references/posting-validation.md",
    "references/bank-reconciliation.md",
    "references/fixed-assets.md",
    "references/migration-and-audit.md",
    "references/month-end-closing.md",
    "references/saudi-tax-rules.md",
    "references/source-notes.md",
    "references/hermes-compatibility.md",
    "scripts/requirements.lock",
    "scripts/bootstrap_skill_runtime.py",
    "scripts/run_validator.py",
    "scripts/validate_accounting_workbook.py",
)
DEFAULT_RUNTIME = Path(os.environ.get(
    "MAFAWIZ_ACCOUNTING_RUNTIME",
    str(Path.home() / ".hermes" / "skill-runtimes" / "real-estate-accounting"),
)).expanduser()


def _frontmatter(text: str) -> dict[str, str]:
    text = text.removeprefix("\ufeff")
    if not text.startswith("---"):
        return {}
    m = re.search(r"\n---\s*\n", text[3:])
    if not m:
        return {}
    block = text[3 : m.start() + 3]
    out: dict[str, str] = {}
    for line in block.splitlines():
        if ":" not in line or line[:1].isspace():
            continue
        key, value = line.split(":", 1)
        out[key.strip()] = value.strip().strip("'\"")
    return out


def _runtime_python(runtime: Path) -> Path:
    return runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _runtime_probe(py: Path) -> tuple[bool, dict[str, str], str]:
    if not py.is_file():
        return False, {}, "runtime_python_missing"
    cmd = [
        str(py), "-c",
        "import json,sys,openpyxl,et_xmlfile; "
        "print(json.dumps({'python':sys.version.split()[0],'openpyxl':openpyxl.__version__,'et_xmlfile':getattr(et_xmlfile,'__version__','unknown')}))",
    ]
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode != 0:
        return False, {}, p.stdout.strip()
    try:
        return True, json.loads(p.stdout), ""
    except Exception as exc:
        return False, {}, f"runtime_probe_parse_error: {exc}: {p.stdout!r}"


def main() -> int:
    skill_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    errors: list[str] = []
    warnings: list[str] = []

    python_ok = sys.version_info[:2] == TARGET_PYTHON
    if not python_ok:
        errors.append(
            f"python_runtime_mismatch: expected {TARGET_PYTHON[0]}.{TARGET_PYTHON[1]}.x, "
            f"got {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        )

    hermes_source = Path(os.environ.get("HERMES_SOURCE_DIR", "/root/hermes-agent"))
    pm_lock = hermes_source / "pm" / "lock.json"
    pm_python_pin = None
    if pm_lock.is_file():
        try:
            lock = json.loads(pm_lock.read_text(encoding="utf-8"))
            pm_python_pin = str(lock["packages"]["python"]["version"])
            pm_base = pm_python_pin.split("+", 1)[0]
            if sys.version.split()[0] != pm_base:
                errors.append(
                    f"python_not_matching_pm_lock: active={sys.version.split()[0]}, pm_lock={pm_python_pin}"
                )
        except Exception as exc:
            errors.append(f"pm_lock_unreadable: {exc}")
    else:
        warnings.append(f"pm_lock_not_found: {pm_lock}")

    missing = [rel for rel in REQUIRED_FILES if not (skill_dir / rel).is_file()]
    if missing:
        errors.append("missing_required_files: " + ", ".join(missing))

    skill_md = skill_dir / "SKILL.md"
    fm = {}
    if skill_md.is_file():
        fm = _frontmatter(skill_md.read_text(encoding="utf-8"))
        if fm.get("name") != "real-estate-accounting":
            errors.append(f"frontmatter_name_invalid: {fm.get('name')!r}")
        if fm.get("version") != "2.0.2":
            errors.append(f"frontmatter_version_invalid: {fm.get('version')!r}")
        if not fm.get("description"):
            errors.append("frontmatter_description_missing")

    cache_dirs = sorted(str(p.relative_to(skill_dir)) for p in skill_dir.rglob("__pycache__") if p.is_dir())
    pyc_files = sorted(str(p.relative_to(skill_dir)) for p in skill_dir.rglob("*.pyc") if p.is_file())
    if cache_dirs or pyc_files:
        errors.append("compiled_python_artifacts_present")

    runtime = DEFAULT_RUNTIME.resolve()
    rpy = _runtime_python(runtime)
    runtime_ok, runtime_info, runtime_error = _runtime_probe(rpy)
    if not runtime_ok:
        errors.append(f"skill_runtime_not_ready: {runtime_error}")
    elif runtime_info.get("python") != sys.version.split()[0]:
        errors.append(
            f"skill_runtime_python_mismatch: runtime={runtime_info.get('python')}, active={sys.version.split()[0]}"
        )

    result = {
        "skill": "real-estate-accounting",
        "skill_version": fm.get("version"),
        "skill_dir": str(skill_dir),
        "python": {
            "version": sys.version.split()[0],
            "target": "3.14.x",
            "compatible": python_ok,
            "hermes_source": str(hermes_source),
            "pm_python_pin": pm_python_pin,
        },
        "isolated_runtime": {
            "path": str(runtime),
            "python": str(rpy),
            "ready": runtime_ok,
            **runtime_info,
        },
        "package": {
            "missing_required_files": missing,
            "pycache_dirs": cache_dirs,
            "pyc_files": pyc_files,
        },
        "warnings": warnings,
        "errors": errors,
        "pass": not errors,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run the workbook validator through the skill's isolated Python runtime."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

DEFAULT_RUNTIME = Path(os.environ.get(
    "MAFAWIZ_ACCOUNTING_RUNTIME",
    str(Path.home() / ".hermes" / "skill-runtimes" / "real-estate-accounting"),
)).expanduser()


def main() -> int:
    runtime = DEFAULT_RUNTIME.resolve()
    py = runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    validator = Path(__file__).resolve().with_name("validate_accounting_workbook.py")
    if not py.is_file():
        print(json.dumps({
            "ok": False,
            "error": "skill_runtime_missing",
            "runtime": str(runtime),
            "hint": "Run scripts/bootstrap_skill_runtime.py with the current Hermes PM Python first.",
        }, ensure_ascii=False, indent=2))
        return 3
    p = subprocess.run([str(py), str(validator), *sys.argv[1:]])
    return p.returncode


if __name__ == "__main__":
    raise SystemExit(main())

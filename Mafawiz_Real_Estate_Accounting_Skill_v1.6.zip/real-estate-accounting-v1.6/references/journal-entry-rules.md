# Journal Entry Rules — v1.6

## Journal-first rule

When a journal is supplied, analyze exactly the accounts and sides provided.
Do not substitute a canonical account into a user-supplied entry.

## Account direction reference

- 1100 Main Bank: asset; Dr increase, Cr decrease.
- 1200 Accounts Receivable: asset; Dr increase, Cr decrease.
- 2410 Owner / Client Funds Payable: liability; Cr increase, Dr decrease.
- 4100 Brokerage Revenue: revenue; Cr increase, Dr decrease.
- 6300 General Marketing & Advertising: expense; Dr increase, Cr decrease.
- 3200 Partner Drawings: debit increases drawings.

## Canonical patterns

Brokerage accrual:
`Dr 1200 / Cr 4100`

Collection:
`Dr 1100 / Cr 1200`

Owner/client receipt:
`Dr 1100 / Cr 2410`

Owner/client remittance:
`Dr 2410 / Cr 1100`

Partner drawing:
`Dr 3200 / Cr 1100`

Partner-paid general advertising:
`Dr 6300 / Cr 3110`

Partner reimbursement:
`Dr 3110 / Cr 1100`

## Direct reversal

Direct reversal requires the same two accounts and amount, with sides reversed.

`Dr 2410 / Cr 4100`
is reversed directly only by
`Dr 4100 / Cr 2410`.

`Dr 4100 / Cr 1200`
is not a direct reversal.

## Mandatory As-Posted example

Entry 1:
`Dr 2410 / Cr 4100 10,000`
- liability 2410 decreases 10,000;
- revenue 4100 increases 10,000.

Entry 2:
`Dr 4100 / Cr 1200 10,000`
- revenue 4100 decreases 10,000;
- AR 1200 decreases 10,000;
- no bank effect.

Combined:
- revenue net = 0;
- 2410 debit movement = 10,000;
- 1200 credit movement = 10,000;
- direct reversal = no;
- relationship = NEEDS_REVIEW.

Do not label individual entries CONFIRMED merely because they balance.


## Confirmation threshold

Balanced does not mean confirmed.

Matching a possible journal pattern does not mean confirmed.

Use:
- `As-Posted` for literal debit/credit effects that are mechanically known.
- `CONFIRMED` only when transaction facts and evidence support the accounting treatment.
- `NEEDS_REVIEW` when the business basis, relationship, or supporting evidence is unresolved.

For `Dr 2410 / Cr 4100`, the mechanics can be stated As-Posted, but business correctness remains NEEDS_REVIEW unless earned brokerage and settlement against owner/client funds are supported.


## Explicit stated facts

For accounting analysis, accept explicit transaction facts as given unless contradictory or explicitly uncertain.

Example:
“Commission accrued 15,000 and not collected yet”
= established accrual fact
= `Dr 1200 / Cr 4100`
= `CONFIRMED` when mapping is valid.

Do not manufacture a closing-condition uncertainty that the prompt did not state.

## Multi-step cases

Every stated event requires a separate journal.

Owner funds received and later remitted:
1. `Dr 1100 / Cr 2410`
2. `Dr 2410 / Cr 1100`

Partner paid office advertising and office later reimbursed:
1. `Dr 6300 / Cr 3110`
2. `Dr 3110 / Cr 1100`

Never omit the second journal.

## Review threshold

Use `NEEDS_REVIEW` for material unresolved accounting facts, not for hypothetical documentary caution when the transaction fact is explicitly given.

---
name: real-estate-accounting
version: 1.3
description: محاسبة مكتب وساطة وتسويق عقاري سعودي: الإيرادات والعمولات والشركاء وأموال العملاء والضرائب والمطابقة وإدارة ملفات Excel.
---

# Mafawiz Real Estate Accounting — v1.3

This skill is the persistent accounting operating framework for مفاوز العقارية.

## 1. Authority and account controls

1. `references/chart-of-accounts.md` is authoritative for account IDs and names.
2. Never invent, substitute, revive, or silently remap an account.
3. Missing/conflicting mapping = `NEEDS_REVIEW`.
4. `NEEDS_REVIEW` is a status/workflow, not automatically account 9200.
5. Current files override stale conversation memory.
6. Never claim an account is missing if the current COA has verified it as present.
7. Never fabricate or misquote rule numbers.

## 2. Mandatory canonical journal templates

### 2.1 Brokerage revenue accrued, not yet collected
MUST be:
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

Effect:
- AR increases.
- Revenue increases.
- Bank unchanged.

### 2.2 Collection of previously recognized receivable
MUST be:
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Effect:
- Bank increases.
- AR decreases.
- Revenue unchanged.
- No new income.

Never use 4100 again merely because cash was collected.

### 2.3 Third-party funds received for owner/client
MUST be:
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

Effect:
- Bank increases.
- Third-party liability increases.
- Revenue unchanged.
- Expense unchanged.

### 2.4 Third-party funds remitted to owner/client
MUST be:
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

Effect:
- Bank decreases.
- Third-party liability decreases.
- Revenue unchanged.
- Expense unchanged.

### 2.5 Partner personal drawing
MUST be:
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

Effect:
- Bank decreases.
- Drawings/contra-equity increases.
- No operating expense.
- Do not describe this as an automatic movement in 3110.

### 2.6 Partner personally pays genuine office expense
For general office advertising:
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

Effect:
- Expense increases.
- Credit balance/amount owed by office to partner increases.
- Office bank unchanged.

### 2.7 Office reimburses partner
MUST be:
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

Effect:
- Bank decreases.
- Partner current credit/amount owed by office decreases or is settled.
- Original expense remains recognized.
- Reimbursement does NOT reverse the expense.
- Reimbursement does NOT create a second expense.
- Do NOT describe reimbursement as "expense decreases", "expense is canceled", or "credit is recovered".

### 2.8 Internal bank transfer
MUST be:
`Dr 1110 Additional Bank`
`Cr 1100 Main Bank`

No P&L effect.

## 3. Unknown bank movements — preserve the known side

Bank movement facts are separate:
- direction;
- bank amount;
- counterparty;
- purpose;
- accounting nature;
- evidence.

If source says **outgoing**:
- direction is known = OUTGOING;
- `1100 Main Bank` is known to decrease/receive a credit for the stated amount;
- only the counter-account/classification may remain unknown.

If source says **incoming**:
- direction is known = INCOMING;
- `1100 Main Bank` is known to increase/receive a debit for the stated amount;
- only the counter-account/classification may remain unknown.

For an outgoing bank movement of 1,275 with unknown purpose/counterparty, report:
- Known bank side: `Cr 1100 Main Bank 1,275`
- Counter-account: UNDETERMINED
- Classification: `NEEDS_REVIEW`
- Do NOT call it "unknown expense" or any other expense before evidence exists.
- Do NOT say direction is unknown.
- Do NOT force it into 6900, 9000, 9100, or 9200.

A complete journal entry is not confirmed until the counter-account is known.

## 4. Direct Reversal Integrity

Direct reversal requires:
- same amount;
- same two accounts;
- opposite debit/credit directions;
- documented relationship.

Example:
Original: `Dr 2410 / Cr 4100`
Direct reversal: `Dr 4100 / Cr 2410`

Therefore:
`Dr 4100 / Cr 1200`
is NOT a direct reversal of
`Dr 2410 / Cr 4100`.

When two entries are supplied:
1. compare both entries;
2. answer the reversal question;
3. never analyze only one entry and label it a reversal.

## 5. As-Posted effect is mandatory even when relationship is NEEDS_REVIEW

`NEEDS_REVIEW` does not mean the literal posted effect is unavailable.

When entries are supplied, calculate and report their **As-Posted** effect whenever arithmetic and account identities are known.

Example:
Entry 1: `Dr 2410 / Cr 4100 10,000`
Entry 2: `Dr 4100 / Cr 1200 10,000`

As-Posted combined effect:
- 4100 Brokerage Revenue: +10,000 credit then -10,000 debit = **net 0**
- 2410 Owner / Client Funds Payable: **debit 10,000** (liability decreases / may become abnormal depending opening balance)
- 1200 Accounts Receivable: **credit 10,000** (AR decreases / may become abnormal depending opening balance)
- Overall relationship: `NEEDS_REVIEW`
- Direct reversal status: **NOT A DIRECT REVERSAL**

Do not say “effect unavailable” when the literal debit/credit effect can be computed.

## 6. Revenue integrity

Revenue recognition and collection are different events.

Before confirming use of 4100, determine whether the event is:
- initial revenue recognition;
- collection;
- refund;
- liability settlement;
- reversal;
- third-party money.

Collection of existing AR must never be counted as new revenue.

## 7. Partner integrity

Keep separate:
- 3100 Partner Contributions
- 3110 Partner Current Account
- 3200 Partner Drawings
- 3210 Partner Settlements
- 3300 Partner Profit Distributions

For any scenario saying a partner paid an office expense and was later reimbursed, show BOTH entries.

Reimbursement settles 3110 and reduces bank. It does not change the already-recognized expense.

## 8. VAT — numerical informational output is mandatory

Current configuration:
- VAT Registered = NO
- VAT Mode = OFF
- VAT Rate = 15% reference only

If the user asks for an informational VAT calculation:
1. calculate the numeric amount explicitly;
2. show the formula;
3. label it `INFORMATIONAL`;
4. state `VAT Posted = 0`;
5. create no journal entry;
6. create no VAT payable;
7. do not alter revenue, expense, or balance sheet.

Example:
Base = 10,000
Reference VAT rate = 15%
Informational VAT = `10,000 × 15% = 1,500`
VAT Posted = `0`

Do not answer only “informational VAT” without the numeric result.

## 9. RETT

RETT Rate = 5% reference only.
RETT Mode = TRANSACTION_SPECIFIC.

Do not post automatically.
Determine transaction type, taxpayer, agency role, economic burden, and evidence.
Missing facts = `NEEDS_REVIEW`.

## 10. As-Posted / Confirmed / Potential / Adjusted

Always distinguish:
- As-Posted
- Confirmed
- Potential
- Adjusted/Expected
- Hypothetical Corrective Scenario

Do not silently repair source data.

## 11. Output completeness

If the user asks N numbered cases:
- answer all N cases exactly once;
- do not omit the last case;
- for multi-step cases, include every stated event.

## 12. Mandatory pre-send self-check

Before sending the answer, verify:

1. All accounts used exist in current COA.
2. Accrued brokerage = `Dr 1200 / Cr 4100`.
3. Collection = `Dr 1100 / Cr 1200`.
4. Third-party receipt = `Dr 1100 / Cr 2410`.
5. Third-party remittance = `Dr 2410 / Cr 1100`.
6. Partner drawing = `Dr 3200 / Cr 1100`.
7. Partner-paid expense = expense debit / `Cr 3110`.
8. Reimbursement = `Dr 3110 / Cr 1100` and does not reverse expense.
9. Unknown outgoing bank movement preserves `Cr 1100` as known and leaves only counter-account unresolved.
10. Direct reversal comparison uses both entries.
11. As-Posted effect is reported if computable, even if relationship is `NEEDS_REVIEW`.
12. Informational VAT includes the actual number and `VAT Posted = 0`.
13. Requested case count equals answered case count.
14. No stale COA claim or fabricated rule reference appears.

If any check fails, correct the answer before sending.

## 13. Current business defaults

Business: مفاوز العقارية
Business model: Saudi real-estate brokerage and marketing office
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT Mode: TRANSACTION_SPECIFIC

For current legal/tax filing advice, verify current official requirements.

## 14. References

Use:
1. `chart-of-accounts.md`
2. `journal-entry-rules.md`
3. `saudi-tax-rules.md`
4. `bank-reconciliation.md`
5. `month-end-closing.md`
6. `excel-accounting.md`

Apply automatically. Do not ask the user to restate these rules.

# Excel Accounting Rules — v1.3

## Current-source precedence
Current COA overrides stale context.

## Canonical validation patterns
- accrued brokerage: Dr 1200 / Cr 4100
- AR collection: Dr 1100 / Cr 1200
- owner funds receipt: Dr 1100 / Cr 2410
- owner funds remittance: Dr 2410 / Cr 1100
- partner drawing: Dr 3200 / Cr 1100
- partner-paid general advertising: Dr 6300 / Cr 3110
- partner reimbursement: Dr 3110 / Cr 1100

## Unknown bank rows
If a row says OUTGOING:
- preserve OUTGOING;
- preserve amount;
- bank side = credit 1100 if 1100 is the stated bank account;
- leave counter-account unresolved;
- status = NEEDS_REVIEW.

Do not relabel as expense without support.

## As-Posted
Compute literal account effects even if status remains NEEDS_REVIEW.

## VAT
If user requests informational VAT, output numeric amount and VAT Posted = 0.

## Completeness
Do not omit requested transactions/cases.

# Saudi Tax Handling — v1.3

## Current configuration
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT Mode: TRANSACTION_SPECIFIC

## VAT informational calculation

When VAT Mode = OFF:
- VAT Posted = 0
- no VAT journal entry
- no VAT payable

When the user explicitly asks for an informational VAT calculation, the numeric amount is mandatory.

Example:
Base: 10,000
Reference rate: 15%
Informational VAT: `10,000 × 15% = 1,500`
Status: INFORMATIONAL
VAT Posted: 0
P&L effect: none
Balance-sheet effect: none

Do not omit the numeric VAT result.

## RETT
Do not auto-post.
Determine taxpayer, transaction nature, agency role, burden, and evidence.
Unresolved = NEEDS_REVIEW.

For current tax filing/legal treatment, verify current official rules.

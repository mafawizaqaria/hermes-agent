# Journal Entry Rules — v1.3

## Canonical entries

### Brokerage commission accrued
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

### Collection of existing receivable
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Collection is not new revenue.

### Owner/client funds received
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

### Owner/client funds remitted
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

### Partner drawing
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

### Partner pays general office advertising personally
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

### Office reimburses partner
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

Reimbursement settles the partner balance. It does not reverse, reduce, cancel, or duplicate the original expense.

## Unknown outgoing bank movement

If the source explicitly says OUTGOING:
- known side = `Cr 1100 Main Bank` for the stated amount;
- counter-account remains UNDETERMINED until evidence supports it;
- status = NEEDS_REVIEW;
- do not classify it as expense merely because cash left the bank.

## Direct reversal

Original:
`Dr A / Cr B`

Direct reversal:
`Dr B / Cr A`

Same amount, same accounts, opposite sides, documented relationship.

## As-Posted analysis

Even where the business relationship is unresolved, calculate the literal ledger effect when entries are known.

Example:
`Dr 2410 / Cr 4100 10,000`
plus
`Dr 4100 / Cr 1200 10,000`

Net As-Posted:
- 4100 net = 0
- 2410 debit movement = 10,000
- 1200 credit movement = 10,000
- not a direct reversal

## Multi-step scenarios

If the prompt contains “then”, “later”, “subsequently”, or two sequential events, show each entry separately.

# Bank Reconciliation Rules — v1.3

## Preserve each known fact independently

Fields:
- direction
- amount
- bank account
- counterparty
- purpose
- accounting nature
- evidence

If movement is stated as OUTGOING:
- direction is known;
- bank decreases;
- known journal side is `Cr 1100 Main Bank` for the stated amount;
- unknown counter-account remains unresolved.

If movement is stated as INCOMING:
- direction is known;
- bank increases;
- known journal side is `Dr 1100 Main Bank` for the stated amount;
- unknown counter-account remains unresolved.

Unknown purpose/counterparty/nature = NEEDS_REVIEW.

Never call an unknown-purpose outgoing movement an “unknown expense”.
Never state that direction is unknown when it was supplied.

Do not force unresolved movements into 6900, 9000, 9100, or 9200.

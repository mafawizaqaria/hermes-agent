# Month-End Closing — v1.3

## Revenue and AR
Accrual: `Dr 1200 / Cr 4100`
Collection: `Dr 1100 / Cr 1200`
Do not double-count revenue.

## Third-party funds
Receipt: Bank ↑, 2410 liability ↑.
Remittance: Bank ↓, 2410 liability ↓.

## Partners
3200 drawings is separate from 3110 current account.
Partner-paid expense remains recognized after reimbursement.
Reimbursement settles 3110 and reduces bank.

## Unknown bank movements
If direction is known, preserve it.
Outgoing unknown-purpose movement still has known bank credit.
Only the counter-account may remain unresolved.

## As-Posted requirement
If journal entries are supplied, calculate literal net account movements even when the business relationship remains NEEDS_REVIEW.

## VAT
Any informational VAT request must include the explicit numeric calculation and VAT Posted = 0 while VAT Mode is OFF.

## Final completeness
Count requested numbered cases and answered cases before finalizing.

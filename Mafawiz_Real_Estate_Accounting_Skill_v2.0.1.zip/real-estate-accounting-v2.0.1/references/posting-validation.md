# Posting Validation — v2.0

## Mandatory principle

`Balanced` is necessary but not sufficient.
`POSTED` is a controlled state, not a label that can be typed onto an invalid row.

## Per-entry validation

Before POSTED:

### Identity
- Journal ID exists and is unique.
- Source/reference exists where materially needed.
- Posting date is a real date.

### Accounts
- Every account exists in current COA.
- Account is permitted for posting.
- Control/group accounts are not used when a dedicated child account is required.
- Debit/credit side is plausible for the transaction.

### Amounts
- Debit/credit amount is numeric.
- No material side is blank.
- No one-sided entry.
- Total debit = total credit.

### Business rules
- AR collection is not new revenue.
- Property principal is not office revenue.
- Third-party money is separated.
- Partner drawings are not expenses.
- Partner reimbursement does not reverse the original expense.
- Financing is not owner/client funds.
- Asset purchase is not automatically an expense.
- Prepaid is not automatically expensed in full.

### Tax
- VAT Mode respected.
- RETT not auto-posted.
- Tax/legal uncertainty remains separate from mechanics.

### Duplicate/correction
- No duplicate active posting.
- Reversal relationship uses same accounts/amount in opposite directions when called a direct reversal.
- Corrected history remains traceable.

## Workbook-level posting gates

A workbook may be called structurally valid only when:
- all POSTED entries are balanced;
- POSTED TB difference = 0;
- no POSTED account missing from COA;
- no duplicate Journal IDs;
- no POSTED row outside the journal table;
- operational dates are real Excel dates;
- reports are based on POSTED only;
- formula errors are absent from critical reports;
- VAT/RETT modes match configuration.

## Review rows

`NEEDS_REVIEW` and `UNPOSTED` may remain in the workbook.

They must:
- be clearly identifiable;
- not affect active GL;
- not affect Trial Balance/P&L/Balance Sheet;
- state unresolved reason;
- preserve the known source facts.

## Prohibited balancing techniques

Never:
- insert an unexplained plug to 9000/9100/9200;
- invent a counter-account;
- change an amount only to make TB zero;
- post Dr Bank / Cr Bank to force a statement balance;
- duplicate an existing payable/expense posting;
- relabel a row POSTED without passing validation.

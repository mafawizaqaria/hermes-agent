# Month-End Closing — v2.0

## Objective

A close is a reconciliation and validation process, not merely a Trial Balance that equals zero.

## Pre-close checklist

1. All active POSTED journals balanced.
2. Review/UNPOSTED queue listed.
3. Bank statement reconciled.
4. Accounts Receivable reviewed.
5. Vendor/payables reviewed.
6. Marketer/external-broker payables reviewed.
7. Owner/client funds 2410 reconciled.
8. Partner current/drawings/contributions reviewed.
9. Loans 2610/2620 reviewed where applicable.
10. Prepaids schedule reviewed.
11. Asset register tied to fixed-asset GL.
12. VAT Mode/RETT status verified.
13. Duplicate/correction queue reviewed.
14. Trial Balance validated.
15. P&L and Balance Sheet tie to GL.

## Closing evidence

Save:
- closing Trial Balance;
- bank reconciliation summary;
- unresolved review list;
- asset/prepaid schedules;
- tax status/configuration snapshot;
- sign-off date/reviewer where used.

## Period protection

After sign-off, avoid casual backdated edits.

If a correction is required:
- preserve original posting;
- document correction;
- use reversal/amendment workflow;
- rerun affected reports and reconciliation.

## Not enough to close

The following alone do not prove a valid close:
- TB difference = 0;
- workbook opens without errors;
- no #REF!;
- totals look reasonable.

A balanced but misclassified or duplicated ledger is still wrong.

# Migration & Audit Trail — v2.0

## Migration is a controlled project

Changing the filename or COA sheet title is not migration.

A migration must preserve historical evidence while building a valid current ledger.

## Required migration layers

### A. Raw / As-Posted history
Keep the original source rows unchanged where possible.

### B. Mapping table
For every historical account:
- old code
- old name
- source/version
- proposed new code
- mapping status
- reason
- reviewer
- notes

### C. Current posting
Only approved mapped rows may become active POSTED entries.

### D. Review queue
Ambiguous rows stay `NEEDS_REVIEW/UNPOSTED`.

## Mapping status

- `APPROVED_DIRECT`
- `APPROVED_CONDITIONAL`
- `NEEDS_REVIEW`
- `NO_MAPPING`
- `OBSOLETE_CONTROL_ACCOUNT`

Do not silently map by numerical similarity.

## Audit trail

Never remove a posted historical fact simply to simplify the workbook.

Use:
- original ID
- corrected/reversal ID
- relationship
- reason
- date
- optional reviewer/approval.

## Duplicate handling

A duplicate is not solved by keeping two active postings with a note.

If duplication is established:
- identify authoritative/original voucher;
- mark duplicate inactive via VOIDED/REVERSED/superseded workflow;
- preserve the record;
- verify active net GL effect.

## Migration validation

After each batch:
- run Trial Balance on POSTED only;
- verify source-to-current mapping;
- check old codes remaining;
- check missing current COA accounts;
- check duplicates;
- check reports.

Do not wait until the end to discover all migration errors.

## Legacy workbook warning

Historical workbook formulas, account names, or account numbers are evidence of prior treatment only.

They do not override:
- current COA;
- source facts;
- current tax configuration;
- posting validation.

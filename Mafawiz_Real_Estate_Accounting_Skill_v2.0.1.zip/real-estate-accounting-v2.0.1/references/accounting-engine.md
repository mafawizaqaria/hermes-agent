# Accounting Engine — v2.0

## Purpose

This reference defines the accounting workflow engine used by the skill.

The accounting system is not "an Excel sheet with numbers". It is a controlled chain:

`Source -> Event -> Mapping -> Validation -> Posting State -> GL -> Reconciliation -> Reports`

This design is consistent with mature ERP accounting workflows where source documents generate or support ledger postings, only submitted/posted records affect the General Ledger, and reports are downstream from posted entries.

## 1. Source layer

A source may be:
- user-stated fact;
- invoice;
- contract;
- bank statement line;
- receipt;
- supplier bill;
- partner reimbursement evidence;
- payment confirmation;
- property/deal reference;
- approved opening balance;
- prior accounting record being migrated.

Source fields should preserve:
- source ID/type;
- source date;
- counterparty/party;
- amount;
- currency;
- description;
- evidence/reference;
- who entered/reviewed it where available.

Do not destroy source history when the accounting treatment changes.

## 2. Accounting event layer

Identify the economic event before the journal.

Examples:
- commission accrued;
- receivable collected;
- owner funds received;
- owner funds remitted;
- office expense paid;
- office expense accrued;
- partner pays office expense;
- partner reimbursed;
- loan received;
- supplier payable recognized;
- asset acquired;
- prepaid recognized;
- bank fee;
- internal bank transfer.

One user scenario may contain multiple events.

## 3. Mapping layer

Map each event to current COA only.

Mapping confidence:
- `DIRECT`: explicit facts and COA determine the account.
- `CONDITIONAL`: account depends on a stated policy/fact.
- `AMBIGUOUS`: more than one materially different treatment remains possible.

Ambiguous mapping = `NEEDS_REVIEW`.
Never hide ambiguity with account `6900`, `9000`, `9100`, or `9200`.

## 4. Posting state

### DRAFT
Work in progress. No GL effect.

### NEEDS_REVIEW
Material fact/mapping/evidence/tax issue unresolved. No GL effect by default.

### UNPOSTED
Entry prepared and balanced but not approved or not past the full posting gate. No GL effect.

### POSTED
Passed posting gate. Included in GL and reports.

### VOIDED
Historical record retained, active GL effect removed/none.

### REVERSED
Correction relationship exists. Original remains auditable; linked reversal creates the opposite accounting effect.

## 5. Posting gate

A POSTED entry must have:
- unique journal ID;
- real posting date;
- source/reference;
- complete debit/credit lines;
- current COA posting accounts;
- balanced total;
- valid status;
- duplicate review;
- tax-mode consistency;
- sufficiently established event.

A one-sided amount is not a valid POSTED entry.

## 6. General Ledger

GL is built only from active POSTED rows.

Every GL line should trace to:
- Journal ID;
- source/reference;
- posting date;
- account;
- debit or credit;
- optional party/deal/property/partner IDs.

Do not edit derived GL rows independently of the journal/source workflow.

## 7. Corrections

Never correct history by silently overwriting a posted record.

Use:
- linked reversal;
- cancellation/void status;
- corrected replacement entry;
- documented reason.

A correction should identify:
- original ID;
- correction/reversal ID;
- reason;
- date;
- approver if applicable.

## 8. Reconciliation

Reconciliation links external statement activity to internal postings.

A reconciliation match is not itself a new revenue/expense unless a new book-side transaction is required.

Bank ending balance is a control total, not a journal entry.

## 9. Reports

Reports are derived from POSTED GL only.

Normal balance formulas:
- Asset = Debit - Credit
- Expense = Debit - Credit
- Liability = Credit - Debit
- Equity = Credit - Debit
- Revenue/Income = Credit - Debit

Never use transaction description text as a substitute for GL account logic when valid postings exist.

## 10. Exceptions

If the user requests an As-Posted analysis of an invalid historical journal:
- analyze it literally;
- do not call it POSTED-valid simply because it exists in the old file;
- separate historical mechanics from proposed current treatment.

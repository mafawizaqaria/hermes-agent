# Saudi Tax Handling — v2.0

**Last official-source review:** 2026-09-29

## Business configuration

- VAT Registered = NO
- VAT Number = NONE
- VAT Mode = OFF
- VAT Rate = 15% reference/informational only
- RETT Rate = 5% reference
- RETT Mode = TRANSACTION_SPECIFIC

This configuration controls accounting behavior until formally changed.

## VAT posting

While VAT Mode = OFF:
- do not add VAT automatically;
- do not post `2330 VAT Payable`;
- VAT Posted = 0;
- informational calculations are allowed when explicitly requested.

Example:
10,000 × 15% = 1,500 informational VAT
VAT Posted = 0

## VAT registration review trigger

Official ZATCA guidance currently states a mandatory registration threshold of SAR 375,000 of taxable supplies for resident persons, with voluntary registration generally available from SAR 187,500 subject to the rules.

The skill must **not** auto-register or auto-enable VAT.

If rolling taxable supplies appear to approach/exceed a current threshold:
- status = `TAX_REGISTRATION_REVIEW`;
- verify current official ZATCA guidance;
- keep accounting mode unchanged until the business confirms registration status.

Taxable supplies are not identical to all cash receipts or property principal.

## E-invoicing

ZATCA states e-invoicing applies to persons subject to VAT and parties issuing tax invoices on their behalf, subject to the current rules/waves.

With current `VAT Registered = NO`, do not automatically activate a ZATCA tax-invoice/e-invoicing posting workflow.

If registration status changes or the user asks about current applicability, verify current ZATCA requirements before changing the skill configuration.

## RETT

Current ZATCA material states RETT is 5% on real estate transactions under the current RETT Law, which replaced the earlier regulation and took effect on 10 April 2025.

For Mafawiz:
- do not apply RETT to every brokerage/marketing transaction;
- determine the real-estate disposition, parties, taxpayer, exemptions, agency/principal role, and who bears the amount;
- do not post `2340` unless office liability is actually established.

Property principal and RETT are not brokerage revenue.

## Source hierarchy

For current Saudi tax/legal applicability use official ZATCA sources first.

Key official sources:
- VAT Implementing Regulations: https://www.zatca.gov.sa/en/RulesRegulations/Taxes/Pages/VATImplementingRegulations.aspx
- VAT registration service/guidance: https://zatca.gov.sa/en/eServices/Pages/eServices-002.aspx
- E-Invoicing FAQ: https://zatca.gov.sa/en/E-Invoicing/Introduction/FAQ/Pages/default.aspx
- E-Invoicing phases: https://zatca.gov.sa/en/E-Invoicing/Introduction/Pages/Roll-out-phases.aspx
- RETT Law: https://www.zatca.gov.sa/en/RulesRegulations/Taxes/Pages/RETTRegulation.aspx

Do not treat this file as a substitute for checking current official rules when the user asks a current legal/tax question.

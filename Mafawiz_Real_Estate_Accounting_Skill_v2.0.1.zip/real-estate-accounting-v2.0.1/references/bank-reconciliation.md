# Bank Reconciliation — v2.0

## Concept

Keep the statement side and book side separate.

- **Bank statement transaction**: external evidence from the bank.
- **Book voucher**: POSTED accounting transaction.
- **Reconciliation**: a match/link or an identified difference.

A statement transaction does not automatically become a Journal Entry.

## Workflow

1. Import/record statement line.
2. Identify direction and amount.
3. Search for matching POSTED voucher(s).
4. If matched: link and mark reconciled.
5. If no book voucher exists but nature is known: prepare the correct journal/payment entry.
6. If nature is unknown: `NEEDS_REVIEW`; keep it out of POSTED GL by default.
7. Recalculate book ending balance and compare with statement ending balance.
8. Explain true timing items/errors.

## Known outgoing line

If statement proves an outgoing amount:
- known analytical side: Bank credit/decrease;
- counter-account may be unknown.

Do not call it an expense without evidence.
Do not post a one-sided journal.

## Closing balance

A bank statement closing balance is a control value.

Do **not** record:
`Dr Bank / Cr Bank`
to make the workbook show the statement balance.

Do not post the entire closing balance as a transaction.

## Internal transfers

If two company bank accounts are involved:
`Dr destination bank`
`Cr source bank`

No revenue/expense effect.

## Bank fees

If clearly identified:
`Dr 6810 Bank Fees`
`Cr 1100 Main Bank`

## Reconciliation Difference account 9100

`9100` is not a universal plug.

Use only under a controlled accounting policy when:
- a real book-side difference is established;
- the difference must temporarily be posted;
- approval/reference exists.

Unknown purpose alone does not justify 9100.

## Reconciliation report

Minimum outputs:
- statement opening balance;
- statement inflows/outflows;
- statement ending balance;
- book ending balance;
- reconciled items;
- unmatched statement items;
- unmatched book items;
- timing differences;
- unexplained difference.

Unexplained difference must be visible, not hidden.

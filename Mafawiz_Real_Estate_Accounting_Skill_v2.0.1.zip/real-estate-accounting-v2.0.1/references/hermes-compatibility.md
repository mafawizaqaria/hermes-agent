# Hermes Compatibility — Skill v2.0.1

Review date: 2026-09-29.

## Target runtime

This skill targets the current Hermes first-party runtime line, which runs on Python 3.14.
The Mafawiz fork's current `pm/lock.json` pins Python `3.14.7+20260901`.

The validator intentionally checks for Python `3.14.x` so it is not accidentally run under an old system interpreter after a Hermes update. The separate compatibility preflight also reads the active source checkout's `pm/lock.json` when available and requires the running Python patch version to match that current PM pin (for the reviewed Mafawiz main: `3.14.7+20260901`).

## Current Hermes skill layout

Current Hermes uses `~/.hermes/skills/` as the primary skill directory and supports:
- `SKILL.md`
- `references/`
- `templates/`
- `scripts/`
- `assets/`

The package uses only supported locations.

## Frontmatter

The skill follows current Hermes frontmatter conventions:
- lowercase/hyphenated `name`;
- concise `description`;
- semantic version;
- platform gate;
- `metadata.hermes.tags`;
- `metadata.hermes.category`;
- `metadata.hermes.related_skills`.

## Python execution

Do not hard-code a path such as:
`~/.hermes/tools/python-3.14.7+20260901-linux-x64/bin/python3`

That PM-managed tool path can change on an update.

For the Mafawiz source deployment, use the current Hermes activation flow:

```bash
cd /root/hermes-agent
source ./activate
python --version
```

Then execute the skill scripts with that `python`.

## Dependency

Workbook validation uses `openpyxl`, matching Hermes' bundled `xlsx` skill approach.
The compatibility checker verifies that `openpyxl` is importable before the skill is installed/used.

## Package hygiene

Do not distribute interpreter-generated files:
- `__pycache__/`
- `*.pyc`

A `.pyc` compiled by Python 3.13 is not a portable artifact for Python 3.14 and is unnecessary because Hermes compiles source as needed.

## Sources reviewed

- Mafawiz fork `pyproject.toml`
- Mafawiz fork `pm/lock.json`
- Mafawiz fork `tools/skill_manager_tool.py`
- Mafawiz fork `agent/skill_utils.py`
- Mafawiz fork `skills/productivity/xlsx/SKILL.md`
- Current NousResearch Hermes installation and skill-system documentation

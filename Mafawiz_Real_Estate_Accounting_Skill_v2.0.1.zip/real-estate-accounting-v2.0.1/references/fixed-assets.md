# Fixed Assets & Prepaids — v2.0

## Fixed-asset principle

Cash paid today does not automatically mean expense today.

Potential Mafawiz fixed-asset accounts:
- `1410 Computers & Office Equipment`
- `1420 Furniture & Fixtures`
- `1430 Leasehold Improvements`

Examples can include computers, office equipment, furniture, installed fit-out, or other items when the capitalization policy and facts support asset recognition.

## Mandatory caution

Do not invent:
- materiality threshold;
- useful life;
- depreciation rate;
- residual value;
- capitalization policy.

If the distinction between expense and asset materially depends on an unprovided policy, use `NEEDS_REVIEW`.

## Asset register

Every POSTED fixed-asset acquisition should appear in the asset register with:
- Asset ID
- acquisition date
- description
- cost
- asset GL account
- source/journal ID
- capitalization basis/status
- disposal status
- depreciation fields only when approved

An asset posted to GL but absent from the asset register is a control exception.

## Leasehold improvements

Installed improvements to a rented office may differ from ordinary repairs/maintenance.

Do not classify painting, electrical work, tile, fit-out, signage, or similar costs solely from the vendor label. Consider:
- nature of work;
- whether benefit extends beyond the current period;
- whether it creates/improves an asset;
- capitalization policy/materiality.

Ambiguous = `NEEDS_REVIEW`.

## Prepaids

For a service covering future periods:
- initial payment may be a prepaid asset;
- periodic recognition transfers the applicable portion to expense.

Example:
`Dr 1310 Prepaid Software & Subscriptions`
`Cr 1100 Main Bank`

Then periodic:
`Dr 6500 Software & Subscriptions Expense`
`Cr 1310 Prepaid Software & Subscriptions`

Do not expense an annual amount in full solely because cash was paid.

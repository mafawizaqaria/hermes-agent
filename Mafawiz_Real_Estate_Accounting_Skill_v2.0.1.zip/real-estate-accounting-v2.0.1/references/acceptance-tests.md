# Acceptance Tests — v2.0

Run these after changes to the skill.

## Test 1 — accrued brokerage commission
Fact: commission 15,000 accrued and not collected.
Expected:
- `Dr 1200 / Cr 4100`
- `POSTED` or `CONFIRMED` treatment if source fact is explicit and mapping valid
- no bank effect

## Test 2 — collection later
Expected:
- `Dr 1100 / Cr 1200`
- no new revenue

## Test 3 — owner funds received then remitted
Expected two events:
1. `Dr 1100 / Cr 2410`
2. `Dr 2410 / Cr 1100`
No P&L effect.

## Test 4 — partner drawing
Expected:
`Dr 3200 / Cr 1100`
Not expense.

## Test 5 — partner pays ad then reimbursed
Expected:
1. `Dr 6300 / Cr 3110`
2. `Dr 3110 / Cr 1100`
Expense recognized once.

## Test 6 — unknown outgoing bank line
Expected:
- known bank decrease analyzed;
- `NEEDS_REVIEW`;
- not a POSTED one-sided journal;
- no invented expense.

## Test 7 — direct reversal integrity
Entry A: `Dr 2410 / Cr 4100 10,000`
Entry B: `Dr 4100 / Cr 1200 10,000`
Expected:
- Direct Reversal = NO
- literal As-Posted effects stated
- business correctness unresolved unless facts establish it.

## Test 8 — informational VAT
10,000 × 15% = 1,500 informational.
VAT Posted = 0.
No journal while VAT Mode OFF.

## Test 9 — office loan
Fact: office receives short-term borrowing 37,700.
Expected:
`Dr 1100 / Cr 2610`
Do not use 2410.

## Test 10 — supplier payable
Fact: office buys materials/services on credit from a normal supplier.
Expected:
`Dr appropriate expense/asset / Cr 2110`
Do not use external-broker payable unless counterparty is an external broker.

## Test 11 — statement closing balance
Fact: statement ending balance = 4,386.20.
Expected:
- no `Dr 1100 / Cr 1100`;
- closing balance is reconciliation control;
- compare against book balance.

## Test 12 — duplicate
Same real event appears twice as active postings.
Expected:
- do not leave both active;
- preserve history;
- void/reverse/supersede duplicate with linkage.

## Test 13 — workbook review rows
Workbook has 10 POSTED balanced entries and 3 NEEDS_REVIEW incomplete rows.
Expected:
- Trial Balance uses 10 POSTED only;
- review rows excluded;
- workbook can structurally pass if review rows are disclosed and all final gates pass.

## Test 14 — old COA workbook
Old sheet contains `1001`, `4001`, `5006`.
Expected:
- never claim migration complete until current journal and active COA use only approved current codes;
- raw old sheet may remain only as clearly labeled historical/migration evidence.

## Test 15 — asset
Computer purchase 4,000 with established capitalization.
Expected:
`Dr 1410 / Cr 1100`
Asset register row required.

## Test 16 — tax threshold signal
Rolling taxable supplies appear near/exceed current official registration threshold.
Expected:
- `TAX_REGISTRATION_REVIEW`;
- verify ZATCA;
- do not auto-enable VAT.

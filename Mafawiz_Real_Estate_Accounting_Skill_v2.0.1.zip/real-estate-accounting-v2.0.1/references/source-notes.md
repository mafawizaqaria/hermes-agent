# External Accounting-System Design Notes — v2.0

**Research review date:** 2026-09-29

These sources inform workflow design. They do not override Mafawiz source facts or the canonical COA.

## ERPNext / Frappe

Official docs reviewed:
- Accounting introduction:
  https://docs.frappe.io/erpnext/accounting-introduction
- Accounting entries:
  https://docs.frappe.io/erpnext/accounting-entries
- Journal Entry:
  https://docs.frappe.io/erpnext/journal-entry
- Chart of Accounts:
  https://docs.frappe.io/erpnext/chart-of-accounts
- General Ledger:
  https://docs.frappe.io/erpnext/general-ledger
- Banking:
  https://docs.frappe.io/erpnext/banking-in-erpnext
- Immutable Ledger:
  https://docs.frappe.io/erpnext/immutable-ledger-in-erpnext
- Freeze Accounting Entries:
  https://docs.frappe.io/erpnext/freeze-accounting-entries
- Accounting Period:
  https://docs.frappe.io/erpnext/accounting-period
- Opening/migration:
  https://docs.frappe.io/erpnext/opening-and-closing

Design lessons adopted:
- source/business documents and submitted vouchers drive GL;
- submitted/posted entries must balance;
- draft records do not affect GL;
- COA type/purpose matters;
- bank statement transactions are distinct from accounting vouchers;
- corrections should preserve audit history rather than silently rewriting ledger rows;
- migration requires approved mapping and reconciled opening balances;
- closed periods should be protected.

## Odoo

Official docs reviewed:
- Chart of Accounts:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/get_started/chart_of_accounts.html
- Accounting cheat sheet:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/get_started/cheat_sheet.html
- Bank reconciliation:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/bank/reconciliation.html
- Bank transactions:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/bank/transactions.html
- Reporting / audit trail:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/reporting.html
- Tax-return lock controls:
  https://www.odoo.com/documentation/19.0/applications/finance/accounting/reporting/tax_returns.html

Design lessons adopted:
- account type determines reporting behavior;
- reconciliation matches external bank transactions with book items;
- reports should drill back to journal/account details;
- accounting changes should be auditable;
- period/tax locks reduce backdated changes after review.

## ZATCA

Official sources reviewed:
- VAT Implementing Regulations
- VAT registration service/guidance
- E-invoicing Regulation / FAQ / phases
- RETT Law and current guideline

Design lessons adopted:
- tax mode is a controlled configuration;
- current legal/tax applicability must be verified from official sources;
- VAT/e-invoicing must not be activated merely because a tax account exists;
- RETT is transaction-specific and subject to current law/exemptions.

## What was NOT copied

The skill does not reproduce ERPNext or Odoo code or proprietary report logic.
It adopts general accounting-control patterns and implements a Mafawiz-specific workflow.

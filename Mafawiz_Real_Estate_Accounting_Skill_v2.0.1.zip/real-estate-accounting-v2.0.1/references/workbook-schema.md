# Workbook Schema — v2.0

## Goal

Excel is the user interface and reporting container. The active accounting truth is the validated POSTED journal/GL, not formatting or file name.

The workbook may use Arabic sheet names and should remain RTL.

## Required logical datasets

Exact sheet names may differ, but the following logical datasets must exist.

### 1. Settings / إعدادات
Recommended fields:
- Business name
- Skill/COA version
- Base currency = SAR
- VAT Registered
- VAT Mode
- VAT Rate reference
- RETT Mode
- RETT Rate reference
- Last validation timestamp
- Validator status

### 2. Chart of Accounts / المخطط المحاسبي
Must mirror current canonical COA.
Recommended columns:
- Code
- Arabic Name
- English Name
- Root Type
- Account Type
- Posting/Control
- Active
- Notes

Old COA may be retained only in a separate migration/audit sheet, not as the active COA.

### 3. Source / Review Queue
Recommended for unresolved bank lines and migration items:
- Source ID
- Source Type
- Date
- Description
- Amount
- Direction
- Counterparty
- Suggested mapping
- Review reason
- Status
- Evidence/reference

This table is not active GL.

### 4. Journal / دفتر اليوميات
Recommended fields:
- Posting Date
- Journal ID
- Source ID
- Description
- Debit Account
- Debit Amount
- Credit Account
- Credit Amount
- Status
- Correction Of
- Deal ID
- Property ID
- Client/Owner ID
- Partner ID
- Bank Transaction ID
- Tax Status
- Notes

If one voucher has multiple debit/credit rows, use a line-level table with Voucher ID + Line No rather than forcing a two-account shape.

### 5. General Ledger / الأستاذ العام
Derived from POSTED journal lines.
Do not maintain independent manual values.

### 6. Bank Reconciliation / المطابقة البنكية
Fields should distinguish:
- Statement Transaction ID
- Statement Date
- Statement Amount
- Direction
- Book Voucher ID
- Match Status
- Difference
- Review note

### 7. Assets / الأصول
Minimum:
- Asset ID
- Acquisition Date
- Description
- Asset Account
- Cost
- Source/Journal ID
- Capitalization Status
- Useful Life / depreciation policy only when approved
- Disposal status

### 8. Liabilities / الالتزامات
Operational schedule for relevant payables/loans.
It does not replace the GL.

### 9. Reports / التقارير
At minimum:
- Trial Balance
- P&L
- Balance Sheet
- Review queue summary
- Bank reconciliation status
- Assets summary where applicable

## Data-type rules

- Dates must be real Excel dates.
- Amounts numeric.
- Account codes stored consistently (prefer text to preserve leading conventions).
- Status must be from the approved state list.
- IDs must not be formulas that can silently renumber history.

## Table-range rules

Use Excel Tables/structured references where practical.

Do not hard-code formulas to a row limit that active transactions can exceed.

Every active row must be inside the relevant table/range.

## Report rules

Reports use POSTED only.

Do not use:
- description keywords as primary account classification;
- hard-coded legacy account codes;
- raw review/unposted rows;
- cached values copied manually when formulas should derive the number.

## RTL

All operational Arabic sheets should set `sheet_view.rightToLeft = True`.

RTL is presentation; it does not replace accounting validation.

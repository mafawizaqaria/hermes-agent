# Journal Entry Rules — v2.0

## 1. Journal supplied by user

Analyze exactly as written:
- actual accounts;
- actual sides;
- literal As-Posted effect.

Do not substitute a canonical template before describing the supplied mechanics.

## 2. Normal account direction

- Asset: Dr increase, Cr decrease.
- Expense: Dr increase, Cr decrease.
- Liability: Cr increase, Dr decrease.
- Equity: Cr increase, Dr decrease, subject to contra-equity accounts.
- Revenue/Income: Cr increase, Dr decrease.

Specific current accounts must be verified in `chart-of-accounts.md`.

## 3. Balanced vs valid

A balanced journal can still be wrong.

`POSTED` requires:
- balanced;
- current COA;
- source/event support;
- duplicate check;
- tax consistency;
- valid date/status.

## 4. Canonical patterns

Brokerage accrual:
`Dr 1200 / Cr 4100`

Collection:
`Dr 1100 / Cr 1200`

Owner/client funds receipt:
`Dr 1100 / Cr 2410`

Owner/client remittance:
`Dr 2410 / Cr 1100`

Partner drawing:
`Dr 3200 / Cr 1100`

Partner-paid general advertising:
`Dr 6300 / Cr 3110`

Partner reimbursement:
`Dr 3110 / Cr 1100`

Short-term loan received:
`Dr 1100 / Cr 2610`

Supplier purchase on credit:
`Dr appropriate expense/asset / Cr 2110`

## 5. Direct reversal

Requires same amount and same accounts, sides reversed.

Original:
`Dr 2410 / Cr 4100`

Direct reversal:
`Dr 4100 / Cr 2410`

`Dr 4100 / Cr 1200` is not a direct reversal.

## 6. Unknown bank movement

For analysis, preserve the known bank side.

For posting, do not create a one-sided POSTED journal.
Keep it in review/reconciliation until the counter-account is known or an approved temporary-posting policy is used.

## 7. Multi-step events

Every event gets its own journal.

Owner funds received then remitted:
1. `Dr 1100 / Cr 2410`
2. `Dr 2410 / Cr 1100`

Partner pays expense then gets reimbursed:
1. `Dr expense / Cr 3110`
2. `Dr 3110 / Cr 1100`

## 8. Explicit facts

Accept explicit stated transaction facts unless contradicted or explicitly uncertain.

Do not downgrade a clearly stated accrued commission merely because a contract was not attached.

## 9. Property principal

Do not post property sale price as Mafawiz revenue merely because the office facilitated the sale.

## 10. Correction

Do not silently overwrite a posted journal.

Use linked correction/reversal/void workflow and preserve audit history.

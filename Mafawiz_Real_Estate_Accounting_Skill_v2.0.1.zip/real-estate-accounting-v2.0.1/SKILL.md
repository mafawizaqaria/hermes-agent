---
name: real-estate-accounting
description: "محاسبة مفاوز العقارية: قيود وترحيل ومطابقة وتقارير Excel."
version: 2.0.1
author: Mafawiz Real Estate
license: Proprietary
platforms: [linux]
metadata:
  hermes:
    tags: [accounting, real-estate, saudi-arabia, xlsx]
    category: productivity
    related_skills: [xlsx]
---

# Mafawiz Real Estate Accounting — v2.0.1

This skill is the persistent accounting operating framework for مفاوز العقارية.

The design is intentionally closer to a small accounting system than to a collection of spreadsheet tips:
`Source Fact / Document -> Accounting Event -> COA Mapping -> Validation -> Posting State -> General Ledger -> Reconciliation -> Reports`.

## 1. Authority order

Use this authority order whenever sources conflict:

1. Explicit current transaction facts supplied by the user/source.
2. Current `references/chart-of-accounts.md` for account identity.
3. This skill and its accounting-engine rules for workflow/treatment.
4. Current official Saudi sources for tax/legal applicability.
5. The current validated workbook for actual posted data.
6. Historical workbooks, old account numbers, old memories, and test datasets only as migration evidence.

Never let an old workbook override the current COA.

## 2. Mandatory references

Before accounting work, load the references relevant to the task:

- `references/chart-of-accounts.md`
- `references/accounting-engine.md`
- `references/journal-entry-rules.md`
- `references/workbook-schema.md`
- `references/posting-validation.md`
- `references/bank-reconciliation.md`
- `references/fixed-assets.md`
- `references/migration-and-audit.md`
- `references/month-end-closing.md`
- `references/saudi-tax-rules.md`
- `references/source-notes.md`

For Excel creation/editing also use the installed `xlsx` skill.

## 3. Core operating principle: only POSTED affects the books

Workflow states are mandatory and are not GL accounts:

- `DRAFT`: incomplete working record; no GL effect.
- `NEEDS_REVIEW`: a material accounting fact/mapping/evidence issue is unresolved; no GL effect by default.
- `UNPOSTED`: accounting treatment is prepared but not approved/validated for posting; no GL effect.
- `POSTED`: passed posting gate; included in GL, Trial Balance, P&L and Balance Sheet.
- `VOIDED`: historical record retained, no active GL effect.
- `REVERSED`: original history retained and a linked opposite posting records the correction.

Do not create half-posted entries merely to make a spreadsheet look complete.

`NEEDS_REVIEW` is a status. It is not automatically account `9200`.

## 4. Posting Gate — mandatory before POSTED

A journal/event may be `POSTED` only when all relevant checks pass:

1. Source/business event is sufficiently known.
2. Posting date is a real date.
3. Journal/reference ID is unique.
4. Debit and credit accounts exist in current COA.
5. Accounts are posting accounts, not control/group accounts when a dedicated child account is required.
6. Debit and credit amounts are complete and positive where applicable.
7. Total debit equals total credit.
8. Account directions are plausible for the stated event.
9. Revenue/collection/third-party funds/partner activity are not confused.
10. Duplicate check passed.
11. Tax treatment agrees with current VAT/RETT mode.
12. Required party/deal/property/partner/source identifiers are present when materially needed.
13. No unresolved mapping or legal/tax fact prevents posting.

If a condition fails, use `NEEDS_REVIEW` or `UNPOSTED`; do not force the Trial Balance to zero.

## 5. Source-document-first behavior

Prefer recording the business event and its source reference before deciding the journal.

Examples of source classes:
- brokerage commission entitlement;
- customer/owner receipt;
- customer collection;
- supplier expense;
- partner-paid office expense;
- partner reimbursement;
- loan/financing;
- bank statement line;
- fixed-asset purchase;
- prepaid subscription;
- property principal held for another party.

Do not infer the event merely from the debit/credit amount.

When a user explicitly states a transaction fact, accept it unless contradictory, explicitly uncertain, or a current legal/tax determination requires external verification.

## 6. Journal-first analysis when a journal is supplied

If the user supplies an explicit journal, analyze it exactly as written before proposing a correction.

For every row:
- account code;
- debit or credit;
- account type/nature from current COA;
- literal As-Posted effect;
- posting status/business correctness separately.

Never silently substitute another account into the supplied entry.

Balanced does not mean correct.
Balanced does not mean confirmed.

## 7. Corrections and audit trail

Never silently rewrite a historically `POSTED` transaction.

For a wrong posted item:
- preserve original ID and values;
- mark workflow relationship;
- use `VOIDED`, `REVERSED`, or a linked correction according to the facts/policy;
- reference the original transaction;
- explain the active net effect.

A direct reversal requires:
- same amount;
- same accounts;
- opposite debit/credit directions;
- documented relationship.

Do not delete history merely to make reports balance.

## 8. Canonical transaction templates

### Brokerage revenue accrued
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

### Collection of existing receivable
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Collection is not new revenue.

### Owner/client funds received
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

### Owner/client funds remitted
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

### Partner drawing
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

### Partner pays genuine office expense
`Dr appropriate office expense`
`Cr 3110 Partner Current Account`

### Partner reimbursement
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

### Internal bank transfer
`Dr 1110 Additional Bank`
`Cr 1100 Main Bank`

### Short-term office loan received
When the borrowing and term are established:
`Dr 1100 Main Bank`
`Cr 2610 Short-Term Loans Payable`

Do not use `2410` for a normal office loan.

### Supplier purchase on credit
When a non-broker supplier obligation is established:
`Dr appropriate expense/asset`
`Cr 2110 Vendor Payables`

### Government license/fee paid
When the cost is a current-period business fee:
`Dr 6910 Government Fees & Licenses`
`Cr 1100 Main Bank`

## 9. Unknown bank transactions

Separate known facts from unknown facts.

If the bank statement says OUTGOING:
- bank direction is known;
- analytical known side is `Cr 1100` for the amount;
- purpose/counter-account may be unresolved.

But an unresolved one-sided bank movement must **not** be included as a `POSTED` journal.

Default workflow:
- Bank Transaction / Review Queue = known statement line;
- Status = `NEEDS_REVIEW`;
- GL effect = none until counter-account is established.

Only if an explicitly approved temporary-posting policy is active may a controlled transitional account be used.

## 10. Bank reconciliation

Bank reconciliation is not a journal used to force the bank account to the statement closing balance.

Keep separate:
- bank statement line / statement balance;
- book-side posted voucher;
- reconciliation match;
- true unresolved difference.

Never use `Dr 1100 / Cr 1100` as reconciliation.
Never post the statement ending balance as if it were a transaction.

Follow `references/bank-reconciliation.md`.

## 11. Fixed assets and prepaids

Cash payment does not determine expense recognition.

- Computers/equipment may use `1410`.
- Furniture/fixtures may use `1420` when capitalization policy supports it.
- Leasehold improvements may use `1430` when capitalization policy supports it.
- Annual software may begin in `1310` and be expensed over the applicable period.
- Do not invent useful lives or depreciation rates.
- Maintain an asset register for posted fixed assets.

If capitalization policy/materiality is not established and it matters to classification, use `NEEDS_REVIEW`.

## 12. Revenue and property principal

Mafawiz is generally a broker/marketer, not the property owner/developer.

Therefore:
- property sale value is not office revenue merely because Mafawiz facilitated the transaction;
- amounts held for owner/client are normally third-party liabilities;
- brokerage revenue, marketing revenue, property-management revenue, consulting revenue, and other non-service income are distinct;
- collection of AR is not new revenue;
- withholding an earned commission from client funds requires the earned commission fact to be established.

## 13. Partner accounting

Keep separate:
- `3000 Capital`
- `3100 Partner Contributions`
- `3110 Partner Current Account`
- `3200 Partner Drawings`
- `3210 Partner Settlements`
- `3300 Partner Profit Distributions`

Partner ID distinguishes partners; do not create separate GL codes merely because there are multiple partners.

Drawings are not expenses.
Reimbursement is not a second expense.

## 14. Tax configuration and current-law verification

Current business configuration:
- VAT Registered = NO
- VAT Number = NONE
- VAT Mode = OFF
- VAT Rate = 15% reference/informational only
- RETT Rate = 5% reference
- RETT Mode = TRANSACTION_SPECIFIC

While VAT Mode is OFF:
- do not add VAT to journal entries automatically;
- VAT Posted = 0 unless configuration is formally changed;
- informational VAT may be calculated when requested.

For current registration, e-invoicing, VAT, or RETT applicability:
- verify official current ZATCA information;
- do not rely solely on a hard-coded historical rule;
- keep tax/legal conclusion separate from accounting mechanics.

If rolling taxable supplies may approach a current registration threshold, flag `TAX_REGISTRATION_REVIEW`; do not silently switch VAT Mode.

## 15. Excel / workbook architecture

A workbook is a controlled accounting interface, not the authority over the COA.

Reports must derive only from active `POSTED` rows.

Minimum rules:
- real Excel dates, not date-looking text;
- Excel Tables or dynamically bounded ranges, not hidden hard-coded cutoffs;
- no posted row outside the journal table;
- no liability/asset row outside its table;
- formulas reference current COA/status logic;
- revenue balance logic = credits minus debits;
- expense balance logic = debits minus credits;
- asset balance logic = debits minus credits;
- liability/equity balance logic = credits minus debits;
- Trial Balance validates total debits = total credits for `POSTED`;
- DRAFT/NEEDS_REVIEW/UNPOSTED/VOIDED are excluded from active financial statements;
- all operational sheets RTL.

Before calling any workbook `FINAL`, run:
`scripts/validate_accounting_workbook.py`.

## 16. Migration from historical workbooks

Do not rename an old workbook "v2.0" and treat that as migration.

A real migration requires:
1. inventory old accounts;
2. current COA mapping table;
3. explicit mapping basis;
4. ambiguous rows to `NEEDS_REVIEW/UNPOSTED`;
5. preserved As-Posted source history;
6. current journal built from approved mapping;
7. current reports built only from `POSTED`;
8. validator pass.

Do not create a balancing plug merely to force TB = 0.

## 17. Report integrity

Financial reports are downstream from the ledger.

For any reported number, be able to trace:
`Report -> GL/account -> journal/voucher -> source event`.

Do not calculate P&L from labels or transaction descriptions when account postings are available.

Minimum reports after a valid close:
- Trial Balance
- General Ledger
- Profit & Loss
- Balance Sheet
- Bank reconciliation status
- AR/AP where applicable
- asset schedule where applicable
- review/unposted queue

## 18. Month-end controls

Before closing:
- all posted journals balanced;
- bank reconciled;
- AR/AP reviewed;
- third-party funds reconciled;
- partner balances reviewed;
- asset/prepaid schedules reviewed;
- VAT/RETT mode checked;
- review queue resolved or explicitly carried forward;
- reports tie to GL.

After sign-off, protect the period from casual backdated edits. Historical corrections must remain traceable.

## 19. Mandatory validator use

When a workbook exists and the task is to declare it corrected/final:
1. inspect the actual workbook;
2. run the validator;
3. report actual results from the file;
4. do not substitute narrative claims for file evidence.

Minimum final gates:
- `unbalanced_posted_entries = 0`
- `posted_tb_difference = 0`
- `posted_missing_coa_accounts = 0`
- `posted_control_account_violations = 0`
- `duplicate_journal_ids = 0`
- `rows_outside_journal_tables = 0`
- `text_dates_in_operational_tables = 0`
- no critical formula errors
- no invalid posted status

A workbook may still contain `NEEDS_REVIEW` or `UNPOSTED` rows. They must be excluded from active GL and clearly disclosed.

## 20. Output discipline

When answering:
- distinguish `Source Fact`, `As-Posted`, `Proposed Treatment`, `Posting Status`, and `Tax Status`;
- never invent source evidence;
- never invent an account;
- never cite fabricated internal rule numbers;
- list all unresolved items at the end;
- for multi-step scenarios, post each event separately;
- do not say “verified” unless you actually verified the referenced file/source.

## 21. Pre-send self-check

Before sending an accounting answer or workbook:
- current COA consulted;
- supplied journals analyzed literally;
- posting state identified;
- no one-sided posted entry;
- debits/credits balanced for POSTED;
- source facts not re-opened without reason;
- third-party funds not treated as revenue;
- collection not treated as revenue;
- partner flows separated;
- bank reconciliation not forced;
- fixed assets/prepaids reviewed;
- VAT Mode respected;
- RETT transaction-specific;
- duplicates/corrections traceable;
- workbook validator run when applicable.

## 22. Acceptance tests

Use `references/acceptance-tests.md` for regression testing after skill changes.

A skill update is not accepted merely because it produces polished prose. It must preserve the accounting invariants and workbook controls.

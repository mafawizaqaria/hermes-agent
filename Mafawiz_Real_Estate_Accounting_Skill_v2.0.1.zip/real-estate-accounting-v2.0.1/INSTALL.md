# Install / Upgrade — v2.0.1

This package targets the current Mafawiz Hermes deployment and current Hermes skill layout.

Compatibility baseline verified on 2026-09-29:
- Hermes skills root: `${HERMES_HOME:-$HOME/.hermes}/skills/`
- Current first-party Hermes runtime: Python 3.14
- Mafawiz fork `pm/lock.json`: Python `3.14.7+20260901`
- CLI wrapper: `hermes` (normally available from `~/.local/bin/hermes`)
- Helper scripts live under the skill's `scripts/` directory, which current Hermes supports.

Do **not** hard-code the Python patch path under `~/.hermes/tools/`; PM may change that path on a future Hermes update.

## 1. Extract to staging

```bash
rm -rf /root/hermes-skill-v2.0.1
mkdir -p /root/hermes-skill-v2.0.1

unzip /root/hermes-agent-download/Mafawiz_Real_Estate_Accounting_Skill_v2.0.1.zip \
-d /root/hermes-skill-v2.0.1
```

## 2. Verify package before touching the active skill

```bash
head -15 /root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1/SKILL.md
find /root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1 -type d -name '__pycache__' -o -type f -name '*.pyc'
```

Expected:
- `version: 2.0.1`
- no `__pycache__` and no `.pyc` files.

## 3. Verify current Hermes runtime

Confirm the CLI and PM-managed runtime first:

```bash
hermes --version
hermes pm status
```

If either command fails, stop before replacing the active skill.

For the Mafawiz source install, activate the current PM-managed Hermes environment rather than relying on an arbitrary system Python:

```bash
cd /root/hermes-agent
source ./activate
python --version
```

Expected for the current Hermes generation: Python `3.14.x`.

Then run the skill compatibility check with that same interpreter:

```bash
python /root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1/scripts/hermes_compat_check.py \
/root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1
```

It must report `pass: true` before installation. On this source deployment it also reads `/root/hermes-agent/pm/lock.json` and verifies that the active interpreter matches Hermes' current pinned Python patch release, rather than trusting only the command name `python`.

The workbook validator also requires `openpyxl`, matching Hermes' bundled `xlsx` skill workflow. The compatibility check verifies that import. If it is unavailable, stop and repair/prepare the Excel environment before installing this skill; do not mutate the Hermes-managed environment blindly. Do not run the validator with a random system interpreter just because it is named `python3`.

## 4. Compile helper scripts under the active Hermes Python

```bash
rm -rf /tmp/mafwiz-pycache-v2.0.1
PYTHONPYCACHEPREFIX=/tmp/mafwiz-pycache-v2.0.1 python -m py_compile \
/root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1/scripts/hermes_compat_check.py \
/root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1/scripts/validate_accounting_workbook.py
rm -rf /tmp/mafwiz-pycache-v2.0.1
```

## 5. Backup current skill

```bash
if [ -d /root/.hermes/skills/productivity/real-estate-accounting ]; then
  cp -a /root/.hermes/skills/productivity/real-estate-accounting \
  /root/.hermes/skills/productivity/real-estate-accounting-backup-pre-v2.0.1-$(date +%Y%m%d-%H%M%S)
fi
```

## 6. Stage, verify, then switch

```bash
rm -rf /root/.hermes/skills/productivity/real-estate-accounting-new

cp -a /root/hermes-skill-v2.0.1/real-estate-accounting-v2.0.1 \
/root/.hermes/skills/productivity/real-estate-accounting-new

head -15 /root/.hermes/skills/productivity/real-estate-accounting-new/SKILL.md
```

If `version: 2.0.1` appears:

```bash
rm -rf /root/.hermes/skills/productivity/real-estate-accounting
mv /root/.hermes/skills/productivity/real-estate-accounting-new \
/root/.hermes/skills/productivity/real-estate-accounting
```

## 7. Verify Hermes skill discovery

```bash
hermes skills list | grep -i real-estate-accounting
```

The skill should be listed as enabled/local.

## 8. Restart the current gateway

```bash
systemctl restart hermes-gateway
systemctl status hermes-gateway --no-pager
```

Do not edit the current systemd unit merely to install this skill.

## 9. Start a fresh Telegram context for acceptance testing

```text
/reset
```

This starts a fresh conversation context so the updated skill catalog is reloaded.

## 10. First validator test

Run from the activated Hermes environment:

```bash
cd /root/.hermes/skills/productivity/real-estate-accounting
python scripts/validate_accounting_workbook.py \
/path/to/workbook.xlsx \
--coa references/chart-of-accounts.md \
--vat-mode OFF
```

Exit codes:
- `0`: validation gates passed.
- `1`: workbook loaded, but one or more critical accounting/workbook gates failed.
- `2`: input/COA problem.
- `3`: `openpyxl` unavailable.
- `4`: wrong Python runtime for the current Hermes compatibility target.

Never force a workbook to pass merely to obtain exit code 0.

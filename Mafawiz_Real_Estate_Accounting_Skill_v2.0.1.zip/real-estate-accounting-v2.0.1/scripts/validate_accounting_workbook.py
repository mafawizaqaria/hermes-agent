#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mafawiz Accounting Workbook Validator — Skill v2.0.1

Read-only validator. It does not modify the workbook.

Usage:
  python validate_accounting_workbook.py FILE.xlsx \
      --coa ../references/chart-of-accounts.md \
      --vat-mode OFF

Outputs JSON to stdout.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from collections import Counter
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

TARGET_PYTHON = (3, 14)
ALLOW_UNSUPPORTED_PYTHON = os.environ.get("MAFAWIZ_VALIDATOR_ALLOW_UNSUPPORTED_PYTHON") == "1"

if sys.version_info[:2] != TARGET_PYTHON and not ALLOW_UNSUPPORTED_PYTHON:
    print(json.dumps({
        "ok": False,
        "error": "unsupported_python_runtime",
        "expected": "Python 3.14.x (current Hermes runtime line)",
        "actual": sys.version.split()[0],
        "hint": "Run from the current Hermes PM-managed environment (source ./activate).",
    }, ensure_ascii=False, indent=2))
    sys.exit(4)

try:
    import openpyxl
    from openpyxl import load_workbook
    from openpyxl.utils.cell import range_boundaries
except Exception as e:
    print(json.dumps({
        "ok": False,
        "error": "openpyxl is required",
        "detail": str(e),
    }, ensure_ascii=False, indent=2))
    sys.exit(3)

STATUS_ALIASES = {
    "POSTED": "POSTED",
    "مرحّل": "POSTED",
    "مرحل": "POSTED",
    "معتمد": "POSTED",
    "NEEDS_REVIEW": "NEEDS_REVIEW",
    "يحتاج مراجعة": "NEEDS_REVIEW",
    "بحاجة مراجعة": "NEEDS_REVIEW",
    "UNPOSTED": "UNPOSTED",
    "غير مرحل": "UNPOSTED",
    "غير مرحّل": "UNPOSTED",
    "DRAFT": "DRAFT",
    "مسودة": "DRAFT",
    "VOIDED": "VOIDED",
    "ملغى": "VOIDED",
    "ملغي": "VOIDED",
    "REVERSED": "REVERSED",
    "معكوس": "REVERSED",
}

ACTIVE_POSTING_STATUSES = {"POSTED"}
VALID_STATUSES = set(STATUS_ALIASES.values())

LIABILITY_STATUS_ALIASES = {
    "OPEN": "OPEN",
    "مفتوح": "OPEN",
    "PAID": "PAID",
    "مدفوع": "PAID",
    "OVERDUE": "OVERDUE",
    "متأخر": "OVERDUE",
    "VOIDED": "VOIDED",
    "ملغى": "VOIDED",
    "ملغي": "VOIDED",
}

JOURNAL_SHEET_CANDIDATES = ["دفتر اليوميات", "Journal", "Journal Entries", "اليومية"]
COA_SHEET_CANDIDATES = ["المخطط المحاسبي", "Chart of Accounts", "COA"]
LIABILITY_SHEET_CANDIDATES = ["سجل الالتزامات", "Liabilities", "Liability Register"]
ASSET_SHEET_CANDIDATES = ["الأصول", "Assets", "Asset Register"]

HEADER_SYNONYMS = {
    "date": ["التاريخ", "تاريخ القيد", "posting date", "date"],
    "journal_id": ["رقم الدفتر", "رقم القيد", "journal id", "voucher id", "entry id"],
    "source_id": ["source id", "معرف المصدر", "مصدر"],
    "description": ["الوصف", "description"],
    "debit_account": ["الحساب المدين", "debit account"],
    "debit_amount": ["المبلغ المدين", "debit amount", "debit"],
    "credit_account": ["الحساب الدائن", "credit account"],
    "credit_amount": ["المبلغ الدائن", "credit amount", "credit"],
    "status": ["الحالة", "status", "posting status"],
    "reference": ["المرجع/العميل/العقار", "المرجع", "reference", "source reference"],
    "notes": ["ملاحظات", "notes"],
}

LIABILITY_HEADERS = {
    "id": ["رقم الالتزام", "liability id"],
    "entry_date": ["تاريخ الإدخال", "entry date"],
    "due_date": ["تاريخ الاستحقاق", "due date"],
    "status": ["الحالة", "status"],
}

ASSET_HEADERS = {
    "id": ["رقم الأصل", "asset id"],
    "date": ["تاريخ الشراء", "acquisition date", "purchase date"],
    "cost": ["التكلفة", "cost"],
}


def norm(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).strip().lower()
    s = re.sub(r"[\u064b-\u065f\u0670]", "", s)
    s = re.sub(r"[\s_\-–—:/\\]+", " ", s)
    return s.strip()


def to_code(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    s = str(v).strip()
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s


def num(v: Any) -> Optional[float]:
    if v is None or v == "":
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        if math.isnan(v) if isinstance(v, float) else False:
            return None
        return float(v)
    try:
        s = str(v).replace(",", "").strip()
        return float(s)
    except Exception:
        return None


def pick_sheet(wb, candidates: List[str]):
    for c in candidates:
        if c in wb.sheetnames:
            return wb[c]
    # normalized fallback
    cmap = {norm(n): n for n in wb.sheetnames}
    for c in candidates:
        if norm(c) in cmap:
            return wb[cmap[norm(c)]]
    return None


def find_header_row(ws, synonyms: Dict[str, List[str]], scan_rows: int = 15) -> Tuple[Optional[int], Dict[str, int]]:
    target = {k: {norm(x) for x in vals} for k, vals in synonyms.items()}
    best = (0, None, {})
    for r in range(1, min(ws.max_row, scan_rows) + 1):
        found: Dict[str, int] = {}
        for c in range(1, ws.max_column + 1):
            n = norm(ws.cell(r, c).value)
            if not n:
                continue
            for key, vals in target.items():
                if n in vals and key not in found:
                    found[key] = c
        score = len(found)
        if score > best[0]:
            best = (score, r, found)
    return best[1], best[2]


def parse_coa_md(path: Path) -> Dict[str, Dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    accounts: Dict[str, Dict[str, Any]] = {}
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(cells) < 5:
            continue
        code = cells[0]
        if not re.fullmatch(r"\d{4}", code):
            continue
        ar = cells[1]
        en = cells[2]
        typ = cells[3]
        rule = cells[4]
        is_control = "control" in typ.lower() or "control" in rule.lower() or "حساب رقابي" in ar
        accounts[code] = {
            "arabic": ar, "english": en, "type": typ, "rule": rule,
            "is_control": is_control,
        }
    return accounts


def table_row_bounds(ws) -> List[Tuple[str, int, int]]:
    out = []
    for name in ws.tables.keys():
        tbl = ws.tables[name]
        min_col, min_row, max_col, max_row = range_boundaries(tbl.ref)
        out.append((name, min_row, max_row))
    return out


def row_inside_any_table(row: int, bounds: List[Tuple[str, int, int]]) -> bool:
    return any(lo <= row <= hi for _, lo, hi in bounds)


def normalize_status(v: Any) -> Optional[str]:
    if v is None or str(v).strip() == "":
        return None
    raw = str(v).strip()
    return STATUS_ALIASES.get(raw) or STATUS_ALIASES.get(raw.upper())


def active_data_rows(ws, id_col: Optional[int], core_cols: List[int], header_row: int) -> List[int]:
    rows = []
    for r in range(header_row + 1, ws.max_row + 1):
        if id_col:
            if ws.cell(r, id_col).value not in (None, ""):
                rows.append(r)
                continue
        if any(ws.cell(r, c).value not in (None, "") for c in core_cols):
            rows.append(r)
    return rows


def scan_formula_info(wb_formula, wb_values) -> Dict[str, Any]:
    formula_count = 0
    errors = []
    formula_sheets = Counter()
    for ws in wb_formula.worksheets:
        vws = wb_values[ws.title] if ws.title in wb_values.sheetnames else None
        for row in ws.iter_rows():
            for cell in row:
                if cell.data_type == "f" or (isinstance(cell.value, str) and cell.value.startswith("=")):
                    formula_count += 1
                    formula_sheets[ws.title] += 1
                    cached = vws[cell.coordinate].value if vws else None
                    if isinstance(cached, str) and cached.startswith("#"):
                        errors.append({
                            "sheet": ws.title, "cell": cell.coordinate,
                            "cached_error": cached,
                        })
                elif cell.data_type == "e" or (isinstance(cell.value, str) and cell.value.startswith("#")):
                    errors.append({
                        "sheet": ws.title, "cell": cell.coordinate,
                        "error": cell.value,
                    })
    return {
        "formula_count": formula_count,
        "formula_count_by_sheet": dict(formula_sheets),
        "formula_errors": errors,
    }


def read_workbook_coa(ws) -> Tuple[set, List[Dict[str, Any]]]:
    if ws is None:
        return set(), []
    hrow, cols = find_header_row(ws, {
        "code": ["الكود", "code", "account code"],
        "name": ["اسم الحساب", "account name", "name"],
    })
    if not hrow or "code" not in cols:
        return set(), []
    codes = set()
    rows = []
    for r in range(hrow + 1, ws.max_row + 1):
        code = to_code(ws.cell(r, cols["code"]).value)
        if code:
            codes.add(code)
            rows.append({"row": r, "code": code, "name": ws.cell(r, cols.get("name", cols["code"])).value})
    return codes, rows


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("workbook")
    ap.add_argument("--coa", required=True, help="Canonical chart-of-accounts.md")
    ap.add_argument("--vat-mode", default="OFF", choices=["OFF", "ON"])
    ap.add_argument("--tolerance", type=float, default=0.005)
    args = ap.parse_args()

    path = Path(args.workbook)
    coa_path = Path(args.coa)
    if not path.exists():
        print(json.dumps({"ok": False, "error": f"Workbook not found: {path}"}, ensure_ascii=False, indent=2))
        return 2
    if not coa_path.exists():
        print(json.dumps({"ok": False, "error": f"COA not found: {coa_path}"}, ensure_ascii=False, indent=2))
        return 2

    coa = parse_coa_md(coa_path)
    if not coa:
        print(json.dumps({"ok": False, "error": "No canonical accounts parsed from COA"}, ensure_ascii=False, indent=2))
        return 2

    wb = load_workbook(path, data_only=False)
    wb_values = load_workbook(path, data_only=True)

    journal_ws = pick_sheet(wb, JOURNAL_SHEET_CANDIDATES)
    coa_ws = pick_sheet(wb, COA_SHEET_CANDIDATES)
    liability_ws = pick_sheet(wb, LIABILITY_SHEET_CANDIDATES)
    asset_ws = pick_sheet(wb, ASSET_SHEET_CANDIDATES)

    result: Dict[str, Any] = {
        "execution_ok": True,
        "validator_version": "2.0.1",
        "runtime": {
            "python": sys.version.split()[0],
            "python_target": "3.14.x",
            "python_compatible": sys.version_info[:2] == TARGET_PYTHON,
            "openpyxl": getattr(openpyxl, "__version__", "unknown"),
        },
        "workbook": str(path),
        "canonical_coa_accounts": len(coa),
        "sheets": wb.sheetnames,
        "rtl": {
            "all_sheets_rtl": all(bool(ws.sheet_view.rightToLeft) for ws in wb.worksheets),
            "non_rtl_sheets": [ws.title for ws in wb.worksheets if not bool(ws.sheet_view.rightToLeft)],
        },
    }

    # Active COA sheet
    workbook_codes, workbook_coa_rows = read_workbook_coa(coa_ws)
    result["workbook_coa"] = {
        "sheet_found": coa_ws.title if coa_ws else None,
        "account_count": len(workbook_codes),
        "missing_canonical_codes": sorted(set(coa) - workbook_codes),
        "extra_codes_not_in_canonical": sorted(workbook_codes - set(coa)),
    }

    # Journal analysis
    journal_report: Dict[str, Any] = {
        "sheet_found": journal_ws.title if journal_ws else None,
    }
    critical_errors = []
    warnings = []

    if journal_ws is None:
        critical_errors.append("journal_sheet_missing")
    else:
        hrow, cols = find_header_row(journal_ws, HEADER_SYNONYMS)
        journal_report["header_row"] = hrow
        journal_report["columns_found"] = cols
        mandatory_cols = ["date", "journal_id", "debit_account", "debit_amount",
                          "credit_account", "credit_amount", "status"]
        missing_cols = [x for x in mandatory_cols if x not in cols]
        journal_report["missing_required_columns"] = missing_cols
        if missing_cols:
            critical_errors.append("journal_required_columns_missing")
        else:
            core_cols = [cols[x] for x in ["journal_id","debit_account","debit_amount","credit_account","credit_amount"]]
            data_rows = active_data_rows(journal_ws, cols["journal_id"], core_cols, hrow)
            bounds = table_row_bounds(journal_ws)
            rows_outside = [r for r in data_rows if bounds and not row_inside_any_table(r, bounds)]
            if data_rows and not bounds:
                rows_outside = data_rows[:]  # active data but no table
            entries = []
            ids = []
            invalid_status_rows = []
            text_date_rows = []
            incomplete_rows = []
            unbalanced_posted = []
            balanced_posted = []
            posted_missing_coa = []
            posted_control = []
            same_account_posted = []
            posted_debit = 0.0
            posted_credit = 0.0
            raw_debit = 0.0
            raw_credit = 0.0
            raw_unbalanced = []
            all_missing_coa = []
            vat_net = 0.0
            rett_net = 0.0
            asset_journal_ids = set()
            j048 = None

            for r in data_rows:
                jid = str(journal_ws.cell(r, cols["journal_id"]).value).strip()
                ids.append(jid)
                dt = journal_ws.cell(r, cols["date"]).value
                if not isinstance(dt, (date, datetime)):
                    text_date_rows.append(r)

                status_raw = journal_ws.cell(r, cols["status"]).value
                status = normalize_status(status_raw)
                if status not in VALID_STATUSES:
                    invalid_status_rows.append({"row": r, "journal_id": jid, "raw": status_raw})

                da = to_code(journal_ws.cell(r, cols["debit_account"]).value)
                ca = to_code(journal_ws.cell(r, cols["credit_account"]).value)
                dv = num(journal_ws.cell(r, cols["debit_amount"]).value)
                cv = num(journal_ws.cell(r, cols["credit_amount"]).value)
                desc = journal_ws.cell(r, cols.get("description", cols["journal_id"])).value
                ref = journal_ws.cell(r, cols.get("reference", cols["journal_id"])).value if "reference" in cols else None

                entry = {
                    "row": r, "journal_id": jid, "date": str(dt) if dt is not None else None,
                    "status_raw": status_raw, "status": status,
                    "debit_account": da, "debit_amount": dv,
                    "credit_account": ca, "credit_amount": cv,
                    "description": desc, "reference": ref,
                }
                entries.append(entry)

                if jid == "J-2026-048" or jid.endswith("-048"):
                    j048 = entry

                rd = dv or 0.0
                rc = cv or 0.0
                raw_debit += rd
                raw_credit += rc
                if not da or not ca or dv is None or cv is None or abs(rd - rc) > args.tolerance:
                    raw_unbalanced.append({
                        "row": r, "journal_id": jid, "debit": rd, "credit": rc,
                        "difference": round(rd-rc, 2),
                    })
                for code, side in [(da, "debit"), (ca, "credit")]:
                    if code and code not in coa:
                        all_missing_coa.append({
                            "row": r, "journal_id": jid, "side": side, "account": code
                        })

                if status == "POSTED":
                    if not da or not ca or dv is None or cv is None:
                        incomplete_rows.append({"row": r, "journal_id": jid})
                    d = dv or 0.0
                    c = cv or 0.0
                    posted_debit += d
                    posted_credit += c
                    if abs(d - c) <= args.tolerance and da and ca and dv is not None and cv is not None:
                        balanced_posted.append(jid)
                    else:
                        unbalanced_posted.append({
                            "row": r, "journal_id": jid, "debit": d, "credit": c,
                            "difference": round(d-c, 2),
                        })

                    for code, side, amount in [(da, "debit", d), (ca, "credit", c)]:
                        if not code or code not in coa:
                            posted_missing_coa.append({
                                "row": r, "journal_id": jid, "side": side, "account": code
                            })
                        elif coa[code]["is_control"]:
                            posted_control.append({
                                "row": r, "journal_id": jid, "side": side, "account": code
                            })

                    if da and ca and da == ca and abs(d-c) <= args.tolerance:
                        same_account_posted.append({"row": r, "journal_id": jid, "account": da, "amount": d})

                    # Tax net liability: credit increases, debit decreases
                    if da == "2330": vat_net -= d
                    if ca == "2330": vat_net += c
                    if da == "2340": rett_net -= d
                    if ca == "2340": rett_net += c

                    if da in {"1410","1420","1430"} or ca in {"1410","1420","1430"}:
                        asset_journal_ids.add(jid)

            duplicate_ids = sorted([jid for jid, n in Counter(ids).items() if n > 1])
            posted_diff = round(posted_debit - posted_credit, 2)
            journal_report.update({
                "actual_journal_entries": len(entries),
                "status_counts": dict(Counter(e["status"] or "INVALID/BLANK" for e in entries)),
                "raw_total_debits_all_rows": round(raw_debit, 2),
                "raw_total_credits_all_rows": round(raw_credit, 2),
                "raw_tb_difference_all_rows": round(raw_debit - raw_credit, 2),
                "raw_unbalanced_entries_all_rows": len(raw_unbalanced),
                "raw_unbalanced_details": raw_unbalanced,
                "all_rows_missing_coa_accounts": len(all_missing_coa),
                "all_rows_missing_coa_details": all_missing_coa,
                "posted_entries": sum(1 for e in entries if e["status"] == "POSTED"),
                "needs_review_entries": sum(1 for e in entries if e["status"] == "NEEDS_REVIEW"),
                "unposted_entries": sum(1 for e in entries if e["status"] == "UNPOSTED"),
                "draft_entries": sum(1 for e in entries if e["status"] == "DRAFT"),
                "voided_entries": sum(1 for e in entries if e["status"] == "VOIDED"),
                "reversed_entries": sum(1 for e in entries if e["status"] == "REVERSED"),
                "balanced_posted_entries": len(balanced_posted),
                "unbalanced_posted_entries": len(unbalanced_posted),
                "unbalanced_posted_details": unbalanced_posted,
                "posted_total_debits": round(posted_debit, 2),
                "posted_total_credits": round(posted_credit, 2),
                "posted_tb_difference": posted_diff,
                "posted_missing_coa_accounts": len(posted_missing_coa),
                "posted_missing_coa_details": posted_missing_coa,
                "posted_control_account_violations": len(posted_control),
                "posted_control_account_details": posted_control,
                "posted_same_account_both_sides": same_account_posted,
                "incomplete_posted_rows": incomplete_rows,
                "duplicate_journal_ids": duplicate_ids,
                "invalid_status_rows": invalid_status_rows,
                "text_dates_in_journal": text_date_rows,
                "journal_tables": [{"name": n, "min_row": lo, "max_row": hi} for n,lo,hi in bounds],
                "rows_outside_journal_tables": rows_outside,
                "vat_posted_net": round(vat_net, 2),
                "rett_posted_net": round(rett_net, 2),
                "asset_posted_journal_ids": sorted(asset_journal_ids),
                "j048": j048,
            })

    # Liabilities
    liab_report: Dict[str, Any] = {"sheet_found": liability_ws.title if liability_ws else None}
    if liability_ws is not None:
        hrow, cols = find_header_row(liability_ws, LIABILITY_HEADERS)
        liab_report["header_row"] = hrow
        liab_report["columns_found"] = cols
        if hrow and "id" in cols:
            core = list(cols.values())
            data_rows = active_data_rows(liability_ws, cols["id"], core, hrow)
            bounds = table_row_bounds(liability_ws)
            outside = [r for r in data_rows if bounds and not row_inside_any_table(r, bounds)]
            if data_rows and not bounds:
                outside = data_rows[:]
            text_dates = []
            invalid_status_values = []
            for r in data_rows:
                for key in ("entry_date","due_date"):
                    if key in cols:
                        v = liability_ws.cell(r, cols[key]).value
                        if v not in (None,"") and not isinstance(v,(date,datetime)):
                            text_dates.append({"row": r, "column": key, "value": str(v)})
                if "status" in cols:
                    raw_status = liability_ws.cell(r, cols["status"]).value
                    if raw_status not in (None, ""):
                        key = str(raw_status).strip()
                        normalized = LIABILITY_STATUS_ALIASES.get(key) or LIABILITY_STATUS_ALIASES.get(key.upper())
                        if normalized is None:
                            invalid_status_values.append({"row": r, "value": raw_status})
            liab_report.update({
                "active_rows": len(data_rows),
                "tables": [{"name": n, "min_row": lo, "max_row": hi} for n,lo,hi in bounds],
                "rows_outside_tables": outside,
                "text_dates": text_dates,
                "invalid_status_values": invalid_status_values,
            })

    # Assets
    asset_report: Dict[str, Any] = {"sheet_found": asset_ws.title if asset_ws else None}
    if asset_ws is not None:
        hrow, cols = find_header_row(asset_ws, ASSET_HEADERS)
        asset_report["header_row"] = hrow
        asset_report["columns_found"] = cols
        if hrow and "id" in cols:
            data_rows = active_data_rows(asset_ws, cols["id"], list(cols.values()), hrow)
            text_dates = []
            if "date" in cols:
                for r in data_rows:
                    v = asset_ws.cell(r, cols["date"]).value
                    if v not in (None,"") and not isinstance(v,(date,datetime)):
                        text_dates.append({"row": r, "value": str(v)})
            asset_report.update({
                "asset_rows": len(data_rows),
                "text_dates": text_dates,
            })

    result["journal"] = journal_report
    result["liabilities"] = liab_report
    result["assets"] = asset_report
    result["formulas"] = scan_formula_info(wb, wb_values)

    # Assemble gates
    jr = journal_report
    if journal_ws is not None and not jr.get("missing_required_columns"):
        if jr.get("unbalanced_posted_entries", 0) != 0:
            critical_errors.append("unbalanced_posted_entries")
        if abs(jr.get("posted_tb_difference", 0.0)) > args.tolerance:
            critical_errors.append("posted_tb_difference_nonzero")
        if jr.get("posted_missing_coa_accounts", 0) != 0:
            critical_errors.append("posted_missing_coa_accounts")
        if jr.get("posted_control_account_violations", 0) != 0:
            critical_errors.append("posted_control_account_violations")
        if jr.get("duplicate_journal_ids"):
            critical_errors.append("duplicate_journal_ids")
        if jr.get("rows_outside_journal_tables"):
            critical_errors.append("rows_outside_journal_tables")
        if jr.get("text_dates_in_journal"):
            critical_errors.append("text_dates_in_journal")
        if jr.get("invalid_status_rows"):
            critical_errors.append("invalid_status_rows")
        if jr.get("incomplete_posted_rows"):
            critical_errors.append("incomplete_posted_rows")
        if jr.get("posted_same_account_both_sides"):
            critical_errors.append("same_account_posted_both_sides")
        if args.vat_mode == "OFF" and abs(jr.get("vat_posted_net", 0.0)) > args.tolerance:
            critical_errors.append("vat_posted_while_mode_off")

    if coa_ws is None or not workbook_codes:
        critical_errors.append("active_workbook_coa_missing_or_unreadable")
    if result["workbook_coa"]["extra_codes_not_in_canonical"]:
        critical_errors.append("active_workbook_coa_has_noncanonical_codes")
    if result["workbook_coa"]["missing_canonical_codes"]:
        critical_errors.append("active_workbook_coa_missing_canonical_codes")

    if jr.get("all_rows_missing_coa_accounts", 0) != 0:
        critical_errors.append("journal_has_noncanonical_account_codes")

    if liab_report.get("rows_outside_tables"):
        critical_errors.append("rows_outside_liability_tables")
    if liab_report.get("text_dates"):
        critical_errors.append("text_dates_in_liabilities")
    if liab_report.get("invalid_status_values"):
        critical_errors.append("invalid_liability_status_values")
    if asset_report.get("text_dates"):
        critical_errors.append("text_dates_in_assets")

    if result["formulas"]["formula_errors"]:
        critical_errors.append("formula_errors")
    if result["formulas"]["formula_count"]:
        warnings.append("formula_semantics_require_acceptance_test")

    if not result["rtl"]["all_sheets_rtl"]:
        warnings.append("some_sheets_not_rtl")

    # asset register warning
    posted_asset_ids = set(jr.get("asset_posted_journal_ids", [])) if isinstance(jr, dict) else set()
    if posted_asset_ids and asset_report.get("asset_rows", 0) == 0:
        warnings.append("posted_fixed_asset_activity_but_asset_register_empty")

    result["validation"] = {
        "critical_errors": sorted(set(critical_errors)),
        "warnings": sorted(set(warnings)),
        "pass": len(set(critical_errors)) == 0,
        "formula_semantics_verified": False,
    }
    result["ok"] = result["validation"]["pass"]

    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0 if result["validation"]["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

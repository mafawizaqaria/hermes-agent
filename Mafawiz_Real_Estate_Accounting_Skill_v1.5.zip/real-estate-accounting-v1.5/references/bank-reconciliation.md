# Bank Reconciliation Rules — v1.4

If source states OUTGOING:
- direction is known;
- bank decreases;
- known side = `Cr 1100 Main Bank` for stated amount;
- counter-account can remain UNDETERMINED;
- status = NEEDS_REVIEW if purpose/counterparty/nature unresolved.

Do not call it an expense without evidence.
Do not claim cash movement unless bank/cash account actually appears in a supplied journal entry.

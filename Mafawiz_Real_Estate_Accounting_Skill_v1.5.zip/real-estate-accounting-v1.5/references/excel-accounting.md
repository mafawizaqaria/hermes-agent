# Excel Accounting Rules — v1.5

## Current COA
Always consult the current chart-of-accounts.md for account existence.

## Supplied journal rows
Analyze the actual debit and credit accounts in the row.
Do not replace them with canonical accounts based on transaction labels.

## Direction
- Asset debit = increase; asset credit = decrease.
- Liability credit = increase; liability debit = decrease.
- Revenue credit = increase; revenue debit = decrease.
- Expense debit = increase; expense credit = decrease.

## As-Posted
Calculate literal account movements even if classification is NEEDS_REVIEW.

## No fabricated bank effect
If 1100 or another bank account is absent from a supplied journal row, do not report bank movement for that row.

## References
Do not cite internal rule numbers in output.


## Confirmation vs As-Posted

Do not use CONFIRMED merely because a row balances.
If business evidence is unresolved:
- mechanics = As-Posted;
- business correctness = NEEDS_REVIEW.

Final review summaries must include all unresolved rows.

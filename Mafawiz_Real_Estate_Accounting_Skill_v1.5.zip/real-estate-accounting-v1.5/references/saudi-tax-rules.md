# Saudi Tax Handling — v1.4

VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference only
RETT Rate: 5% reference only
RETT Mode: TRANSACTION_SPECIFIC

If informational VAT is requested:
- compute numeric amount;
- show formula;
- status = INFORMATIONAL;
- VAT Posted = 0;
- no journal entry.

Example:
10,000 × 15% = 1,500
VAT Posted = 0

RETT is transaction-specific and is not posted automatically.

# Month-End Closing — v1.5

Before finalizing:
- consult current COA;
- analyze supplied journal lines exactly as written;
- verify debit/credit effects by account nature;
- never invent a bank effect when 1100/1110 is absent;
- compute As-Posted effects even when business correctness is NEEDS_REVIEW;
- separate drawings from partner current;
- keep partner reimbursement from reversing expense;
- include numeric informational VAT where requested;
- do not cite internal rule numbers.


## Review-summary completeness

Before finalizing:
- list every transaction/case with unresolved business correctness;
- list every transaction/case with unknown counter-account, purpose, party, evidence, tax treatment, or entry relationship;
- do not omit a NEEDS_REVIEW case from the final summary merely because its As-Posted mechanics are calculable.

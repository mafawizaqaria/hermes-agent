---
name: real-estate-accounting
version: 1.4
description: محاسبة مكتب وساطة وتسويق عقاري سعودي: الإيرادات والعمولات والشركاء وأموال العملاء والضرائب والمطابقة وإدارة ملفات Excel.
---

# Mafawiz Real Estate Accounting — v1.4

This skill is the persistent accounting operating framework for مفاوز العقارية.

## Authority

- `references/chart-of-accounts.md` is the authoritative source for account IDs and account names.
- Current files override stale conversation memory.
- Never invent, substitute, revive, or silently remap accounts.
- Missing/conflicting mapping = `NEEDS_REVIEW`.
- `NEEDS_REVIEW` is a workflow/status, not automatically account 9200.
- Do not modify the COA automatically.

## Mandatory COA verification

Before stating that an account:
- exists,
- does not exist,
- is required,
- is missing,
- conflicts with another mapping,

you MUST read/consult the current `references/chart-of-accounts.md`.

If the current COA verifies an account as present, do not say:
- “if it exists”,
- “if it is available”,
- “it may be missing”,
- “cannot be verified”.

Give a definitive answer based on the current COA.

## Do not cite rule numbers

Do NOT cite internal rule numbers such as “Rule 2.3”, “Rule 12”, or “COA Rule #6”.

Instead, refer only to rule names, for example:
- `Brokerage Revenue Accrual`
- `Collection of Existing Receivable`
- `Third-Party Funds`
- `Partner Drawings`
- `Partner Reimbursement`
- `Unknown Bank Movements`
- `Direct Reversal Integrity`
- `VAT Informational Calculation`

This prevents stale or fabricated numbering.

## Journal-first analysis — mandatory

When the user supplies an explicit journal entry, analyze the entry AS WRITTEN before matching it to any business template.

For each line:
1. identify the actual account number;
2. identify debit or credit;
3. identify the account's normal nature from the current COA;
4. calculate the literal As-Posted effect;
5. only then assess whether the business treatment is correct.

Never replace a supplied account with a different account merely because another canonical template looks similar.

Example:
User supplies:
`Dr 4100 / Cr 1200`

You MUST analyze:
- 4100 is debited;
- 1200 is credited;
- there is NO 1100 in this entry;
- therefore do NOT describe cash/bank as increasing.

## Account-direction mechanics

For the canonical accounts:

### 1100 Main Bank — Asset
- Debit = increase
- Credit = decrease

### 1200 Accounts Receivable — Asset
- Debit = increase
- Credit = decrease

### 2410 Owner / Client Funds Payable — Liability
- Credit = increase
- Debit = decrease

### 3110 Partner Current Account
Interpret according to documented partner balance:
- Credit generally increases amount owed by office to partner.
- Debit generally settles/reduces that credit balance.

### 3200 Partner Drawings — Contra-equity / Drawings
- Debit increases drawings.
- Not an operating expense.

### 4100 Brokerage Revenue — Revenue
- Credit = increase revenue
- Debit = decrease/reverse revenue

### 6300 General Marketing & Advertising — Expense
- Debit = increase expense
- Credit = decrease/reverse expense

## Canonical journal templates

### Brokerage Revenue Accrual
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

### Collection of Existing Receivable
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Collection is not new revenue.

### Third-Party Funds — Receipt
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

Bank increases; liability increases.

### Third-Party Funds — Remittance
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

Bank decreases; liability decreases.

### Partner Drawings
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

### Partner-Paid Office Expense
For general office advertising:
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

### Partner Reimbursement
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

The original expense remains recognized.

### Internal Bank Transfer
`Dr 1110 Additional Bank`
`Cr 1100 Main Bank`

No P&L effect.

## Unknown Bank Movements

Known and unknown facts must stay separate.

If source says OUTGOING:
- direction is known = OUTGOING;
- bank decreases;
- known journal side = `Cr 1100 Main Bank` for the stated amount;
- counter-account may remain unresolved.

Do not call it an expense unless evidence supports an expense account.

Status = `NEEDS_REVIEW` when purpose/counterparty/nature is unresolved.

## Direct Reversal Integrity

A direct reversal requires:
- same amount;
- same two accounts;
- opposite debit/credit directions;
- documented relationship.

Example:

Original:
`Dr 2410 / Cr 4100 10,000`

Direct reversal would be:
`Dr 4100 / Cr 2410 10,000`

This is NOT a direct reversal:
`Dr 4100 / Cr 1200 10,000`

because `1200 != 2410`.

## Mandatory As-Posted analysis

Even if business treatment is `NEEDS_REVIEW`, calculate literal effects when the entry is known.

For:
Entry 1: `Dr 2410 / Cr 4100 10,000`
Entry 2: `Dr 4100 / Cr 1200 10,000`

MUST report:

Entry 1 As-Posted:
- 2410 debit 10,000 -> liability decreases by 10,000.
- 4100 credit 10,000 -> revenue increases by 10,000.

Entry 2 As-Posted:
- 4100 debit 10,000 -> revenue decreases by 10,000.
- 1200 credit 10,000 -> accounts receivable decreases by 10,000.
- No bank/cash movement because account 1100 is absent.

Combined As-Posted:
- 4100 net revenue effect = 0.
- 2410 net debit movement = 10,000.
- 1200 net credit movement = 10,000.
- Direct Reversal = NO.
- Relationship/business correctness = `NEEDS_REVIEW`.

Never call either entry `CONFIRMED` merely because its individual debits equal credits.

## VAT Informational Calculation

Current configuration:
- VAT Registered = NO
- VAT Mode = OFF
- VAT Rate = 15% reference only

If user asks for informational VAT:
- calculate numeric VAT;
- show formula;
- status = `INFORMATIONAL`;
- VAT Posted = 0;
- no journal entry;
- no VAT payable.

Example:
`10,000 × 15% = 1,500`
VAT Posted = `0`

## RETT

RETT Rate = 5% reference only.
RETT Mode = TRANSACTION_SPECIFIC.

Do not post automatically.
Determine transaction, taxpayer, agency role, economic burden, and evidence.
Unresolved = `NEEDS_REVIEW`.

## Output completeness

If the user requests N cases:
- answer all N exactly once;
- include all steps in multi-event cases;
- do not omit final cases.

## Final self-check before answer

Verify:
- current COA was consulted for account-existence claims;
- supplied entries were analyzed exactly as written;
- no account was substituted into the user's entry;
- debit/credit effects match account nature;
- no cash effect is claimed unless a cash/bank account appears;
- third-party liability debit decreases liability; credit increases it;
- revenue debit decreases revenue; credit increases it;
- direct reversal compares both entries;
- As-Posted effect is shown even if treatment is NEEDS_REVIEW;
- unknown outgoing movement preserves known bank credit;
- partner reimbursement does not reverse expense;
- informational VAT includes numeric result and VAT Posted = 0;
- no internal rule numbers are cited;
- all requested cases are answered.

## Current business defaults

Business: مفاوز العقارية
Business model: Saudi real-estate brokerage and marketing office
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT Mode: TRANSACTION_SPECIFIC

For current legal/tax filing advice, verify current official requirements.

## References

Use:
1. `chart-of-accounts.md`
2. `journal-entry-rules.md`
3. `saudi-tax-rules.md`
4. `bank-reconciliation.md`
5. `month-end-closing.md`
6. `excel-accounting.md`

Apply automatically.

# Journal Entry Rules — v1.4

## Journal-first rule

When a journal is supplied, analyze exactly the accounts and sides provided.
Do not substitute a canonical account into a user-supplied entry.

## Account direction reference

- 1100 Main Bank: asset; Dr increase, Cr decrease.
- 1200 Accounts Receivable: asset; Dr increase, Cr decrease.
- 2410 Owner / Client Funds Payable: liability; Cr increase, Dr decrease.
- 4100 Brokerage Revenue: revenue; Cr increase, Dr decrease.
- 6300 General Marketing & Advertising: expense; Dr increase, Cr decrease.
- 3200 Partner Drawings: debit increases drawings.

## Canonical patterns

Brokerage accrual:
`Dr 1200 / Cr 4100`

Collection:
`Dr 1100 / Cr 1200`

Owner/client receipt:
`Dr 1100 / Cr 2410`

Owner/client remittance:
`Dr 2410 / Cr 1100`

Partner drawing:
`Dr 3200 / Cr 1100`

Partner-paid general advertising:
`Dr 6300 / Cr 3110`

Partner reimbursement:
`Dr 3110 / Cr 1100`

## Direct reversal

Direct reversal requires the same two accounts and amount, with sides reversed.

`Dr 2410 / Cr 4100`
is reversed directly only by
`Dr 4100 / Cr 2410`.

`Dr 4100 / Cr 1200`
is not a direct reversal.

## Mandatory As-Posted example

Entry 1:
`Dr 2410 / Cr 4100 10,000`
- liability 2410 decreases 10,000;
- revenue 4100 increases 10,000.

Entry 2:
`Dr 4100 / Cr 1200 10,000`
- revenue 4100 decreases 10,000;
- AR 1200 decreases 10,000;
- no bank effect.

Combined:
- revenue net = 0;
- 2410 debit movement = 10,000;
- 1200 credit movement = 10,000;
- direct reversal = no;
- relationship = NEEDS_REVIEW.

Do not label individual entries CONFIRMED merely because they balance.

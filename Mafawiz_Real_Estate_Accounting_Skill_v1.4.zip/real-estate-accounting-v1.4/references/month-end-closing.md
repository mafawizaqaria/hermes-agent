# Month-End Closing — v1.4

Before finalizing:
- consult current COA;
- analyze supplied journal lines exactly as written;
- verify debit/credit effects by account nature;
- never invent a bank effect when 1100/1110 is absent;
- compute As-Posted effects even when business correctness is NEEDS_REVIEW;
- separate drawings from partner current;
- keep partner reimbursement from reversing expense;
- include numeric informational VAT where requested;
- do not cite internal rule numbers.

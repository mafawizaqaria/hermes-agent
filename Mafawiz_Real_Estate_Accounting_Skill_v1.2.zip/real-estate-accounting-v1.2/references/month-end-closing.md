# Month-End Closing — v1.2

## Revenue integrity
Accrued brokerage: `Dr 1200 / Cr 4100`.
Collection of prior AR: `Dr 1100 / Cr 1200`.
Never count collection twice.

## Third-party funds
Receipt: bank increases and 2410 liability increases.
Remittance: bank decreases and 2410 liability decreases.

## Partners
3200 drawings is separate from 3110 current account.
Partner-paid office expense remains recognized after reimbursement.
Reimbursement: `Dr 3110 / Cr 1100`; it does not reverse expense.

## Completeness
If analysis contains numbered cases, verify every requested case is present before final output.

## Final self-check
- correct debit/credit sides;
- correct asset/liability directions;
- revenue vs collection correct;
- known bank direction preserved;
- Direct Reversal compared using both entries;
- no missing case;
- no fabricated rule references.

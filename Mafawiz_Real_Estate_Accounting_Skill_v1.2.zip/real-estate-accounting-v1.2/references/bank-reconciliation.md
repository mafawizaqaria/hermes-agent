# Bank Reconciliation Rules — v1.2

Treat these as separate facts:
- direction;
- counterparty;
- purpose;
- accounting nature;
- supporting evidence.

If source says OUTGOING, direction is known.
If source says INCOMING, direction is known.
Unknown counterparty/purpose/nature does not make direction unknown.

If purpose/counterparty/nature cannot be established: `NEEDS_REVIEW`.
Do not automatically classify as expense, revenue, partner activity, or third-party funds.

Internal transfer: `Dr 1110 / Cr 1100`.
Known bank fee: `Dr 6810 / Cr 1100`.

Do not use 6900, 9000, 9100, or 9200 merely to force reconciliation.

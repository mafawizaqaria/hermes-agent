# Excel Accounting Rules — v1.2

Current loaded COA overrides stale conversation memory.
Validate every account against the current canonical COA.

Canonical validation patterns:
- accrued brokerage: `Dr 1200 / Cr 4100`
- prior-AR collection: `Dr 1100 / Cr 1200`
- owner funds receipt: `Dr 1100 / Cr 2410`
- owner funds remittance: `Dr 2410 / Cr 1100`
- partner drawing: `Dr 3200 / Cr 1100`
- partner-paid general advertising: `Dr 6300 / Cr 3110`
- partner reimbursement: `Dr 3110 / Cr 1100`

Do not collapse multi-event scenarios into one row/event.
Preserve known bank direction independently from unknown purpose/counterparty.

When asked to analyze N transactions/cases, verify exactly N outputs are present.
Keep As-Posted, Confirmed, Potential, Adjusted/Expected, and Hypothetical Corrective Scenario separate.

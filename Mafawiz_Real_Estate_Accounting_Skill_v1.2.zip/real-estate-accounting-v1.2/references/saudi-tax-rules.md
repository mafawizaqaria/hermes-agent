# Saudi Tax Handling

## Current configuration
- VAT Registered: NO
- VAT Mode: OFF
- VAT Rate: 15% reference only
- RETT Rate: 5% reference only
- RETT Mode: TRANSACTION_SPECIFIC

## VAT
When VAT Mode is OFF:
- VAT Posted = 0
- no output VAT posting
- no input VAT posting
- no automatic VAT addition

Informational VAT may be calculated when explicitly requested, but must remain INFORMATIONAL and must not become a posted liability automatically.

## RETT
Do not automatically post 5% RETT.
Determine:
- transaction type;
- taxpayer;
- whether Mafawiz is principal or agent;
- who bears the amount;
- supporting documentation.

If unresolved: `NEEDS_REVIEW`.

When current tax advice or filing treatment is requested, verify current official requirements.

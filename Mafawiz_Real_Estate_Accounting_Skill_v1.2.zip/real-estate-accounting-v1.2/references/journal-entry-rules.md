# Journal Entry Rules — v1.2

## Canonical patterns

### Brokerage commission accrued
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

Never reverse these sides for initial accrual.

### Collection of existing AR
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Collection is not new revenue and must not use 4100 again.

### Owner/client funds received
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

Bank increases. Liability increases. P&L unchanged.

### Owner/client funds remitted
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

Bank decreases. Liability decreases. P&L unchanged.

### Partner drawing
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

No operating expense. Do not describe this as an automatic decrease in 3110.

### Partner-paid office expense
For general advertising:
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

Expense increases. Credit to 3110 represents amount/current balance owed to partner.

### Reimbursement to partner
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

Bank decreases. Partner current settles. Original expense remains recognized. No expense reversal.

## Direct Reversal test
A Direct Reversal uses the same amount and same two accounts on opposite sides.

Original: `Dr A / Cr B`
Direct reversal: `Dr B / Cr A`

Thus `Dr 2410 / Cr 4100` is directly reversed only by `Dr 4100 / Cr 2410`.
`Dr 4100 / Cr 1200` is NOT its Direct Reversal.

When a prompt provides two entries, compare both entries; never classify only the first entry as a reversal.

## Multi-step scenarios
If the scenario says “then”, “later”, “subsequently”, or describes multiple events, record and explain every event separately.

## Source integrity
Do not invent “COA Rule #X” or quote a rule number that does not exist in the loaded reference.

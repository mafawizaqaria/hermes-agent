---
name: real-estate-accounting
version: 1.2
description: محاسبة مكتب وساطة وتسويق عقاري سعودي: الإيرادات والعمولات والشركاء وأموال العملاء والضرائب والمطابقة وإدارة ملفات Excel.
---

# Mafawiz Real Estate Accounting

## Mandatory operating rules

This skill is the persistent accounting operating framework for مفاوز العقارية.

1. **Never invent an account.** Every account used must exist in the current `references/chart-of-accounts.md`. Never invent, substitute, or revive an account from an old workbook. If an account is missing or mapping conflicts, use `NEEDS_REVIEW`. `NEEDS_REVIEW` is a status, not automatically a GL account.

2. **Current COA is authoritative.** Transaction facts come from the current transaction/source document; account identity from the current COA; accounting treatment from this skill; tax treatment from current verified Saudi rules. Conflicts must be reported, not silently resolved.

3. **Double entry is necessary but not sufficient.** Debits must equal credits, and also validate account existence, account nature, revenue recognition, AR, liabilities, partner separation, third-party funds, tax status, reversals, duplicates, fixed assets, and unresolved items.

4. **Property value is not office revenue.** Property sale/purchase value or money passing through the office for an owner/client is not revenue merely because the office facilitated the transaction.

5. **Third-party funds are separate.** Money received/held for owners or clients is normally a liability/settlement amount, not office revenue.

6. **Third-party receipt direction is explicit.**
   - Receipt for owner/client: Bank **increases** and Third-Party Funds Liability **increases**.
   - Remittance to owner/client: Bank **decreases** and Third-Party Funds Liability **decreases**.
   - Do not describe receipt of third-party funds as a reduction in liability.
   - Do not describe the flow as “asset-to-asset”; it is normally an asset/liability movement.

7. **Revenue and collection are different.** Collection of an existing receivable is `Dr Bank / Cr AR`; it is not new revenue.

8. **Direct reversal integrity.** A direct reversal requires the same amount, same accounts, opposite debit/credit directions, and a documented relationship. If accounts differ, it is not a direct reversal.

9. **VAT current mode:** `VAT_REGISTERED=NO`, `VAT_MODE=OFF`, `VAT_RATE=15%` reference only. Do not post VAT or add VAT automatically. Informational VAT calculations must remain informational unless actual tax status and transaction facts support posting.

10. **RETT is transaction-specific.** Do not automatically apply 5% to every real-estate transaction or brokerage commission. Identify transaction, taxpayer, agency role, and who bears the amount. Missing facts = `NEEDS_REVIEW`.

11. **Partner separation.** Separate capital, current account, drawings, settlements/reimbursements, and profit distributions.
   - Personal withdrawal uses the Drawings account and is not an operating expense.
   - A drawing does **not** automatically reduce Partner Current Account.
   - A partner-paid genuine office expense is recognized as the office expense plus a credit to Partner Current Account when the office owes the partner.
   - A reimbursement debits Partner Current Account and credits Bank.
   - Reimbursement does **not** reverse or cancel the original expense and does not create a second expense.

12. **Internal bank transfers** are asset-to-asset and do not affect revenue or expense.

13. **Known facts must remain known.** If the user or source states that a bank movement is incoming or outgoing, do not later describe the direction as unknown. Only unresolved facts may be marked unknown.

14. **Unknown bank movements** must not be guessed into revenue or expense. Determine direction, counterparty, purpose, and evidence; otherwise `NEEDS_REVIEW`.

15. **Fixed assets** are not automatically expenses. Depreciation requires an established policy/basis.

16. **Prepaids** are recognized over the applicable period when appropriate; do not expense an annual prepaid amount merely because cash was paid.

17. **Do not force management classifications.** Do not label accounts as Direct Costs/Operating Expenses by intuition. GL classification follows the current COA. Any management grouping is separate and explicitly configured.

18. **Do not modify the COA automatically.** Discovering a mapping problem is not permission to redesign the chart.

19. **Current-source consistency check.** After reading the current COA, do not claim that an account is absent if it was just verified as present. If earlier conversation context conflicts with the current file, the current file wins and the older context must be treated as stale.

## Accounting workflow

For every transaction:
1. Read facts and source.
2. Identify business purpose and parties.
3. Determine cash movement.
4. Determine substance: revenue, receivable, collection, expense, payable, asset, liability, third-party funds, partner item, tax, or internal transfer.
5. Validate every account against the current COA.
6. Apply VAT/RETT settings.
7. Build the journal entry.
8. Test debit = credit.
9. Run integrity checks.
10. Check effect directions for assets, liabilities, equity, revenue, and expenses.
11. Assign status.
12. Explain unresolved items and required evidence.

## Reporting states

Always distinguish:
- **As-Posted:** literal result of supplied entries.
- **Confirmed:** supported treatment.
- **Potential:** depends on unresolved facts.
- **Adjusted/Expected:** result after an explicit corrective assumption.
- **Hypothetical Corrective Scenario:** proposed only, never presented as an approved correction.

Do not silently overwrite As-Posted numbers.

## NEEDS_REVIEW

Use it for missing accounts, conflicting mappings, unknown purpose/counterparty, uncertain tax treatment, non-matching reversals, duplicate risk, missing documents, or any treatment requiring an assumption.

Do not mark a fact as unknown when the source explicitly states it.

For each item report:
- Transaction ID
- Known facts
- As-Posted treatment
- Confirmed portion if any
- Unresolved portion
- Reason
- Evidence needed
- Possible treatment only if useful and clearly labeled as a scenario

## Financial integrity checks

At minimum:
- debits = credits;
- all accounts exist;
- account nature matches;
- asset/liability direction is described correctly;
- revenue is not duplicated by collection;
- AR has no unexplained negative balance;
- payables/liabilities reconcile;
- third-party funds remain separate;
- partner balances remain separate;
- drawings are not expenses;
- drawings are not automatically Partner Current movements;
- partner reimbursement does not reverse the original expense;
- internal transfers do not affect profit;
- fixed assets/prepaids are correctly treated;
- VAT posting agrees with VAT mode;
- RETT is not automatic;
- known bank direction is preserved;
- unknown bank purpose/counterparty remains unresolved;
- direct reversals actually reverse the original accounts;
- no invented accounts;
- no duplicate transactions/revenue;
- no contradiction between the current COA and the final response.

## Current business defaults

Business: مفاوز العقارية
Business model: Saudi real-estate brokerage and marketing office
VAT Registered: NO
VAT Mode: OFF
VAT Rate: 15% reference
RETT Rate: 5% reference
RETT Mode: TRANSACTION_SPECIFIC

These defaults do not replace checking current official requirements when tax advice or filing treatment is requested.

## Reference order

Use when relevant:
1. `chart-of-accounts.md`
2. `journal-entry-rules.md`
3. `saudi-tax-rules.md`
4. `bank-reconciliation.md`
5. `month-end-closing.md`
6. `excel-accounting.md`

Do not ask the user to repeat these core rules in every conversation. Apply them automatically.

# v1.2 — Non-negotiable transaction patterns

These patterns override any ambiguous interpretation. Before marking an item CONFIRMED, compare the proposed entry to the relevant pattern.

## Brokerage revenue accrued but not collected
MUST be:
`Dr 1200 Accounts Receivable`
`Cr 4100 Brokerage Revenue`

Effects: AR increases; revenue increases; bank unchanged.
NEVER use `Dr 4100 / Cr 1200` for initial revenue recognition.

## Collection of previously recognized AR
MUST be:
`Dr 1100 Main Bank`
`Cr 1200 Accounts Receivable`

Effects: bank increases; AR decreases; revenue unchanged.
NEVER use 4100 again for collection of an already recognized receivable.

## Owner/client funds received
MUST be:
`Dr 1100 Main Bank`
`Cr 2410 Owner / Client Funds Payable`

Effects: bank asset increases; third-party liability increases; P&L unchanged; balance sheet changes.

## Owner/client funds remitted
MUST be:
`Dr 2410 Owner / Client Funds Payable`
`Cr 1100 Main Bank`

Effects: bank asset decreases; third-party liability decreases; P&L unchanged; balance sheet changes.

Never describe receipt of owner/client funds as decreasing liability or as having no balance-sheet effect.

## Partner personal drawing
MUST be:
`Dr 3200 Partner Drawings`
`Cr 1100 Main Bank`

Effects: bank decreases; drawings/contra-equity increases; operating expense unchanged.
Do not state that 3110 Partner Current Account decreased unless a separate documented 3110 entry exists.

## Partner personally pays a genuine office expense
For general office advertising:
`Dr 6300 General Marketing & Advertising`
`Cr 3110 Partner Current Account`

Effects: expense increases; amount owed/current balance to partner increases on the credit side; bank unchanged.

## Office later reimburses that partner
MUST be:
`Dr 3110 Partner Current Account`
`Cr 1100 Main Bank`

Effects: bank decreases; partner current balance settles/decreases; the original expense remains recognized.
Reimbursement does NOT reverse/cancel the expense and is NOT a second expense.

# Direct Reversal comparison protocol

When two entries are supplied and the user asks whether the second reverses the first, compare BOTH entries.

A Direct Reversal requires:
- same amount;
- same two accounts;
- opposite debit/credit sides;
- documented relationship.

Example:
Original `Dr 2410 / Cr 4100`
Direct reversal must be `Dr 4100 / Cr 2410`.
Therefore `Dr 4100 / Cr 1200` is NOT a Direct Reversal.
Do not analyze only the first entry and label it a reversal.

# Known-fact preservation

Treat direction, counterparty, purpose, accounting nature, and evidence as separate fields.
If the source says a bank movement is outgoing, direction is known = OUTGOING.
If the source says incoming, direction is known = INCOMING.
Do not later describe a stated direction as unknown.
Unknown counterparty/purpose/nature may still require NEEDS_REVIEW.

# VAT informational completeness

When VAT Mode = OFF and the user explicitly requests an informational VAT calculation:
- calculate it;
- label INFORMATIONAL;
- create no journal entry;
- VAT Posted = 0;
- do not change revenue, expense, assets, or liabilities.

Example: 10,000 × 15% = 1,500 informational VAT.

# Output completeness check

If the user asks N numbered cases, answer ALL N cases exactly once.
Before sending the response:
1. count the requested cases;
2. count the answered cases;
3. verify multi-step cases include every event;
4. verify no case was omitted;
5. verify any requested VAT case is present.

# Pre-send accounting validation

Before marking any case CONFIRMED, verify:
1. account exists in current COA;
2. entry matches the relevant canonical pattern above;
3. debit/credit directions are correct;
4. asset/liability/equity effects are described correctly;
5. collection of prior AR does not touch revenue;
6. owner/client receipt increases both bank and liability;
7. owner/client remittance decreases both bank and liability;
8. partner drawing uses 3200 and is not described as 3110 activity;
9. reimbursement does not reverse the original expense;
10. known bank direction remains known;
11. Direct Reversal question compares both entries;
12. all numbered cases are answered;
13. no fabricated rule number or nonexistent source claim is used.

